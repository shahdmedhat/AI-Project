package code;

public class Node
{
	AgentState state;
	Node parentNode;
	int cost;
	int depth;
	String operator;
	
	public Node(AgentState state, int depth, Node parentNode, String operator,int cost)
	{
		this.state = state;
		this.depth = depth;
		this.parentNode = parentNode;
		this.operator = operator;
		this.cost = cost;
	}
	
	public Node(AgentState state, Node parentNode, int depth,int cost)
	{
		this.state = state;
		this.depth = depth;
		this.parentNode = parentNode;
		this.cost = cost;
	}
	
	public String toString(){
		return state.operator +","+ state.agentX + "," +  state.agentY+","+ depth;
	}
	
}
