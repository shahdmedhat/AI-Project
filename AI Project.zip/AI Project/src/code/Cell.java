package code;

import java.util.ArrayList;

public class Cell {
	
	boolean empty;
	boolean ship;
	boolean station;
//	boolean agent;

	int x;
	int y;
	
	int sizeX;
	int sizeY;
	
	ArrayList<String> actions = new ArrayList<String>();
	//ArrayList<Ship> ships = new ArrayList<Ship>();

	public Cell(int m , int n) {
		empty = true;
		ship = false;
		station = false;
		//agent = false;
		sizeX = m;
		sizeY = n;
		//ships = sh;
	}
	
	public boolean isShip() {
		return ship;
	}
	public void setShip(boolean ship) {
		this.ship = ship;
	}
	
	public boolean isStation() {
		return station;
	}
	public void setStation(boolean station) {
		this.station = station;
	}
	
	public boolean isEmpty() {
		return empty;
	}

	public void setEmpty(boolean empty) {
		this.empty = empty;
	}
	
//	public boolean isAgent() {
//		return agent;
//	}

//	public void setAgent(boolean agent) {
//		this.agent = agent;
//	}
	
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
	
//	public ArrayList<Ship> getShips() {
//		return ships;
//	}
//
//	public void setShips(ArrayList<Ship> ships) {
//		this.ships = ships;
//	}
	
//	public void possibleActions() {
//		if (this.x != 0) {
//			this.actions.add("up");
//		}
//		
//		if (this.x != sizeX-1) {
//			this.actions.add("down");
//		}
//		
//		if (this.y != 0) {
//			this.actions.add("left");
//		}
//		
//		if (this.y != sizeY-1) {
//			this.actions.add("right");
//		}
//		
//		if (this.ship && this.agent) {
//			this.actions.add("pickup");
//			this.actions.add("retrieve");	
//		}
//		
//		if (this.station && this.agent) {
//			this.actions.add("drop");
//		}
//		
//	}
	
}
