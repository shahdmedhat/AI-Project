package code;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Comparator;
import java.util.Queue;
import java.util.Stack;

public class CoastGuard {
	String grid;
	int[] cell;
	int remainingPass;
	int maxNoOfPass;
	int noOfShips;
	static Object[][] gridArr;
	static ArrayList<String> visitedStates = new ArrayList<String>();
	static ArrayList<Station> stations;
	int remainingAlivePass;
	int[] goalTest = new int[3];
	int[]  initialState= new int[2];
	
	
	static Agent agent;
	static int m;
	static int n;
	static int c;
	int deaths = 0;
	static int blackBoxesCollected = 0;
	static int totalDeaths = 0;
	static int nodesExpanded = 0;
	static int remainingPassengers;
	static ArrayList<Ship> ships = new ArrayList<Ship>();
	static Cell[][] gr;
	Queue<String> bfsQ = new LinkedList<>(); 
	static boolean yallaRetrieve = false;
	
	public CoastGuard(int x, int y, int remainingPass, int maxNoOfPass, int[] goalTest, int remainingAlivePass) {
		this.cell = new int[2];
		this.cell[0] = x;
		this.cell[1] = y;
		this.remainingPass = remainingPass;
		this.maxNoOfPass = maxNoOfPass;
		this.goalTest = clone(goalTest);
		this.remainingAlivePass = remainingAlivePass;
	}

	public CoastGuard() {
		this.cell = new int[2];
	}

	public static String solve(String grid, String strategy, boolean visualize) {
		Node n = null;
		if (strategy == "BF")
			n = BF(grid);

		else if (strategy == "DF")
			n = DF(grid);

		else if (strategy == "ID")
			n = ID(grid);

		else if (strategy == "GR1")
			n = GR1(grid);

		else if (strategy == "GR2")
			n = GR2(grid);

		else if (strategy == "AS1")
			n = AS1(grid);

		else if (strategy == "AS2")
			n = AS2(grid);
		else
			return "";

		if (visualize) {
			//-----------------------------------
		}


		return getNodeParents(n);
	}

	public static String getNodeParents(Node n) {
		if (n == null)
			return "No Solution";
		String output = "";
		int num = 0;
		AgentState state = n.state;
		int deadPass = state.deadPassengers;
		int blackBoxesRetrieved = state.boxesRetrieved;
		while (n != null && n.parentNode != null) {
			output = n.operator + "," + output;
			n = n.parentNode;
			num++;

		}
		if (output.length() > 0)
			return output.substring(0, output.length() - 1) + ";" + deadPass + ";" + blackBoxesRetrieved + ";" + num;
		return "No Solution";
	}

	public static ArrayList<Ship> clone(ArrayList<Ship> arr) {
		ArrayList<Ship> clone = new ArrayList<Ship>();

		for (int i = 0; i < arr.size(); i++) {
			Ship ship = arr.get(i);
			clone.add(clone(ship));
		}

		return clone;
	}
	

	public static Ship clone(Ship ship) {
		return new Ship(ship.getX(), ship.getY(), ship.remainingPassengers, ship.blackBoxTimeRemaining,
				ship.blackBoxRetrieved);
	}

	public static int[] clone(int[] arr) {
		int[] clone = new int[arr.length];

		for (int i = 0; i < arr.length; i++) {
			clone[i] = arr[i];
		}

		return clone;
	}

	public static Node BF(String grid) {
		CoastGuard coastGuard = new CoastGuard();
		Queue<Node> queue = new LinkedList<Node>();
		queue.add(InitializeCoastGuard(coastGuard, grid));
		visitedStates = new ArrayList<String>();

		while (!queue.isEmpty()) {
			Node node = queue.remove();
			AgentState state = node.state;
			CoastGuard cg = state.coastGuard;
			int[] currCell = cg.cell;
			int savedPass = state.safePassengers;
			int remainingPass = cg.remainingPass;
			int deadPass = state.deadPassengers;
			int blackBoxRetrieved = state.boxesRetrieved;
			int remainingAlivePass = cg.remainingAlivePass;

			// Check if the cell is a ship or a station or neither
			boolean st = false;

			if (gridArr[currCell[0]][currCell[1]] instanceof Station)
				st = true;

			if (node.operator != null) {
				if (node.operator.equals("pickup")) {
					int x = pickup(state, cg, currCell);
					savedPass += x;
					remainingPass -= x;
					remainingAlivePass -= x;
				}
				if (node.operator.equals("drop")) {
					cg.goalTest[0] = 0;
					remainingPass = cg.maxNoOfPass;
				}
				if (node.operator.equals("retrieve")) {
					int index = getShip(state.wreckedShips, currCell);
					if (index != -1) {
						Ship ship = state.wreckedShips.get(index);
						ship.blackBoxRetrieved = true;
						cg.goalTest[2]--;
						state.boxesRetrieved += 1;
					}
					blackBoxRetrieved += 1;
				}
			}

			Ship s = null;

			// Handling the loss of a passenger every step
			ArrayList<Ship> safeShips = clone(state.safeShips);
			ArrayList<Ship> wreckedShips = clone(state.wreckedShips);

			if (node.parentNode != null) {
				
				ArrayList<Ship> newWrecked = new ArrayList<Ship>();
				for (int i = 0; i < safeShips.size(); i++) {
					Ship ship = safeShips.get(i);
					
					if(ship.remainingPassengers > 0)
					{
						ship.remainingPassengers -= 1;
						deadPass += 1;
						remainingAlivePass -= 1;
					}
					
					if(ship.remainingPassengers == 0)
					{
						ship.blackBoxTimeRemaining-=1;
						newWrecked.add(ship);
					}

					if (ship.getX()== currCell[0] && ship.getY()== currCell[1]) {
						s = ship;
					}

				}

				safeShips.removeAll(newWrecked);

				for (int i = 0; i < wreckedShips.size(); i++) {
					Ship ship = wreckedShips.get(i);

					if (!ship.blackBoxRetrieved && ship.blackBoxTimeRemaining == 1) {
						cg.goalTest[2]--;
						ship.blackBoxTimeRemaining -= 1;
					}

					if (!ship.blackBoxRetrieved && ship.blackBoxTimeRemaining > 0)
						ship.blackBoxTimeRemaining -= 1;

					if (!ship.blackBoxRetrieved && ship.blackBoxTimeRemaining > 0 && ship.getX() == currCell[0]
							&& ship.getY() == currCell[1])
						s = ship;
				}

				wreckedShips.addAll(newWrecked);

			}

			// Check if we reached the goal test
			if (cg.goalTest[0] == 0 && cg.goalTest[2] == 0)
				return node;

			String hash = state.stateToString();

			// Adding nodes to the queue
			if (!contains(visitedStates, hash)) {
				visitedStates.add(hash);

				CoastGuard newCG = new CoastGuard(currCell[0], currCell[1], remainingPass, cg.maxNoOfPass, cg.goalTest,
						remainingAlivePass);
				AgentState newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved,savedPass);

				if (s != null && !s.blackBoxRetrieved && s.blackBoxTimeRemaining > 0) { // current Node is a ship
					if (s.remainingPassengers > 0 && remainingPass > 0) {
						queue.add(new Node(newState, node.depth + 1, node, "pickup", node.cost + 1));
					} else if (s.remainingPassengers == 0 && !s.blackBoxRetrieved && s.blackBoxTimeRemaining > 0) {
						queue.add(new Node(newState, node.depth + 1, node, "retrieve", node.cost + 1));
					}

				} else if (st == true && remainingPass < cg.maxNoOfPass) {
					queue.add(new Node(newState, node.depth + 1, node, "drop",node.cost + 1));
				}

				else {
					if (currCell[0] > 0) {
						newCG = new CoastGuard(currCell[0] - 1, currCell[1], remainingPass, cg.maxNoOfPass, cg.goalTest,
								remainingAlivePass);
						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved,savedPass);
						queue.add(new Node(newState, node.depth + 1, node, "up", node.cost + 1));
					}

					if (currCell[0] < (gridArr.length - 1)) {
						newCG = new CoastGuard(currCell[0] + 1, currCell[1], remainingPass, cg.maxNoOfPass, cg.goalTest,
								remainingAlivePass);
						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved,savedPass);
						queue.add(new Node(newState, node.depth + 1, node, "down",node.cost + 1));
					}

					if (currCell[1] > 0) {
						newCG = new CoastGuard(currCell[0], currCell[1] - 1, remainingPass, cg.maxNoOfPass, cg.goalTest,
								remainingAlivePass);
						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
						queue.add(new Node(newState, node.depth + 1, node, "left", node.cost + 1));
					}

					if (currCell[1] < (gridArr[0].length - 1)) {
						newCG = new CoastGuard(currCell[0], currCell[1] + 1, remainingPass, cg.maxNoOfPass, cg.goalTest,
								remainingAlivePass);
						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
						queue.add(new Node(newState, node.depth + 1, node, "right", node.cost + 1));
					}
				}

			}

		}

		return null;
	}

	public static Node DF(String grid) {
		CoastGuard coastGuard = new CoastGuard();
		Stack<Node> stack = new Stack<Node>();
		stack.add(InitializeCoastGuard(coastGuard, grid));
		ArrayList<String> visitedStates = new ArrayList<String>();
		
		while (!stack.isEmpty()) {
			Node node = stack.pop();
			AgentState state = node.state;
			CoastGuard cg = state.coastGuard;
			int[] currCell = cg.cell;
			int savedPass = state.safePassengers;
			int remainingPass = cg.remainingPass;
			int deadPass = state.deadPassengers;
			int blackBoxRetrieved = state.boxesRetrieved;
			int remainingAlivePass = cg.remainingAlivePass;

			// Check if the cell is a ship or a station or neither
			boolean st = false;

			if (gridArr[currCell[0]][currCell[1]] instanceof Station)
				st = true;

			if (node.operator != null) {
				if (node.operator.equals("pickup")) {
					int x = pickup(state, cg, currCell);
					savedPass += x;
					remainingPass -= x;
					remainingAlivePass -= x;
				}
				if (node.operator.equals("drop")) {
					cg.goalTest[0] = 0;
					remainingPass = cg.maxNoOfPass;
				}
				if (node.operator.equals("retrieve")) {
					int index = getShip(state.wreckedShips, currCell);
					if (index != -1) {
						Ship ship = state.wreckedShips.get(index);
						ship.blackBoxRetrieved = true;
						state.boxesRetrieved += 1;
						cg.goalTest[2]--;
						blackBoxRetrieved += 1;
					}

				}
			}
			
			Ship s = null;

			// Handling the loss of a passenger every step
			ArrayList<Ship> safeShips = clone(state.safeShips);
			ArrayList<Ship> wreckedShips = clone(state.wreckedShips);

			if (node.parentNode != null) {
				ArrayList<Ship> newWrecked = new ArrayList<Ship>();
				for (int i = 0; i < safeShips.size(); i++) {
					Ship ship = safeShips.get(i);

					if(ship.remainingPassengers > 0)
					{
						ship.remainingPassengers -= 1;
						deadPass += 1;
						remainingAlivePass -= 1;
					}
					
					if(ship.remainingPassengers == 0)
					{
						ship.blackBoxTimeRemaining-=1;
						newWrecked.add(ship);
					}

					if (ship.getX() == currCell[0] && ship.getY()== currCell[1]) {
						s = ship;
					}

				}

				safeShips.removeAll(newWrecked);

				for (int i = 0; i < wreckedShips.size(); i++) {
					Ship ship = wreckedShips.get(i);

					if (!ship.blackBoxRetrieved && ship.blackBoxTimeRemaining == 1) {
						cg.goalTest[2]--;
						ship.blackBoxTimeRemaining -= 1;
					}

					if (!ship.blackBoxRetrieved && ship.blackBoxTimeRemaining > 0)
						ship.blackBoxTimeRemaining -= 1;

					if (!ship.blackBoxRetrieved && ship.blackBoxTimeRemaining > 0 && ship.getX() == currCell[0]
							&& ship.getY() == currCell[1])
						s = ship;
				}

				wreckedShips.addAll(newWrecked);

			}

			// Check if we reached the goal test
			if (cg.goalTest[0] == 0 && cg.goalTest[2] == 0)
				return node;

			String hash = state.stateToString();
			
			
			
			// Adding nodes to the queue
			if (!contains(visitedStates, hash)) {
				visitedStates.add(hash);

				CoastGuard newCG = new CoastGuard(currCell[0], currCell[1], remainingPass, cg.maxNoOfPass, cg.goalTest,remainingAlivePass);
				AgentState newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
				
				if (s != null && !s.blackBoxRetrieved && remainingPass != 0) { // current Node is a ship
					if (s.remainingPassengers > 0) {
						stack.add(new Node(newState, node.depth + 1, node, "pickup", node.cost + 1));
					} else if (!s.blackBoxRetrieved && s.blackBoxTimeRemaining > 0) {
						stack.add(new Node(newState, node.depth + 1, node, "retrieve", node.cost + 1));
					}

				} else if (st == true && remainingPass < cg.maxNoOfPass) {
					stack.add(new Node(newState, node.depth + 1, node, "drop", node.cost + 1));
				}

				else {
					if (currCell[0] > 0) {
						newCG = new CoastGuard(currCell[0] - 1, currCell[1], remainingPass, cg.maxNoOfPass, cg.goalTest,
								remainingAlivePass);
						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
						stack.add(new Node(newState, node.depth + 1, node, "up", node.cost + 1));
					}

					if (currCell[0] < (gridArr.length - 1)) {
						newCG = new CoastGuard(currCell[0] + 1, currCell[1], remainingPass, cg.maxNoOfPass, cg.goalTest,
								remainingAlivePass);
						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
						stack.add(new Node(newState, node.depth + 1, node, "down", node.cost + 1));
					}

					if (currCell[1] > 0) {
						newCG = new CoastGuard(currCell[0], currCell[1] - 1, remainingPass, cg.maxNoOfPass, cg.goalTest,
								remainingAlivePass);
						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
						stack.add(new Node(newState, node.depth + 1, node, "left", node.cost + 1));
					}

					if (currCell[1] < (gridArr[0].length - 1)) {
						newCG = new CoastGuard(currCell[0], currCell[1] + 1, remainingPass, cg.maxNoOfPass, cg.goalTest,
								remainingAlivePass);
						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
						stack.add(new Node(newState, node.depth + 1, node, "right", node.cost + 1));
					}
				}

			}

		}

		return null;
	}

	public static Node ID(String grid) {
		for (int depth = 0;; depth++) {
			CoastGuard coastGuard = new CoastGuard();
			Stack<Node> stack = new Stack<Node>();
			stack.add(InitializeCoastGuard(coastGuard, grid));
			ArrayList<String> visitedStates = new ArrayList<String>();

			while (!stack.isEmpty()) {
				Node node = stack.pop();
				AgentState state = node.state;
				CoastGuard cg = state.coastGuard;
				int[] currCell = cg.cell;
				int savedPass = state.safePassengers;
				int remainingPass = cg.remainingPass;
				int deadPass = state.deadPassengers;
				int blackBoxRetrieved = state.boxesRetrieved;
				int remainingAlivePass = cg.remainingAlivePass;

				// Check if the cell is a ship or a station or neither
				boolean st = false;

				if (gridArr[currCell[0]][currCell[1]] instanceof Station)
					st = true;

				if (node.operator != null) {
					if (node.operator.equals("pickup")) {
						int x = pickup(state, cg, currCell);
						savedPass += x;
						remainingPass -= x;
						remainingAlivePass -= x;
					}
					if (node.operator.equals("drop")) {
						cg.goalTest[0] = 0;
						remainingPass = cg.maxNoOfPass;
					}
					if (node.operator.equals("retrieve")) {
						int index = getShip(state.wreckedShips, currCell);
						if (index != -1) {
							Ship ship = state.wreckedShips.get(index);
							ship.blackBoxRetrieved = true;
							state.boxesRetrieved += 1;
							cg.goalTest[2]--;
							blackBoxRetrieved += 1;
						}

					}
				}

				Ship s = null;

				// Handling the loss of a passenger every step
				ArrayList<Ship> safeShips = clone(state.safeShips);
				ArrayList<Ship> wreckedShips = clone(state.wreckedShips);

				if (node.parentNode != null) {
					ArrayList<Ship> newWrecked = new ArrayList<Ship>();
					for (int i = 0; i < safeShips.size(); i++) {
						Ship ship = safeShips.get(i);
						if(ship.remainingPassengers > 0)
						{
							ship.remainingPassengers -= 1;
							deadPass += 1;
							remainingAlivePass -= 1;
						}
						
						if(ship.remainingPassengers == 0)
						{
							ship.blackBoxTimeRemaining-=1;
							newWrecked.add(ship);
						}

						if (ship.getX() == currCell[0] && ship.getY() == currCell[1]) {
							s = ship;
						}

					}

					safeShips.removeAll(newWrecked);

					for (int i = 0; i < wreckedShips.size(); i++) {
						Ship ship = wreckedShips.get(i);

						if (!ship.blackBoxRetrieved && ship.blackBoxTimeRemaining == 1) {
							cg.goalTest[2]--;
							ship.blackBoxTimeRemaining = 0;
						}

						if (!ship.blackBoxRetrieved && ship.blackBoxTimeRemaining > 0)
							ship.blackBoxTimeRemaining -= 1;

						if (!ship.blackBoxRetrieved && ship.blackBoxTimeRemaining > 0 && ship.getX() == currCell[0]
								&& ship.getY() == currCell[1])
							s = ship;
					}

					wreckedShips.addAll(newWrecked);
				}

				// Check if we reached the goal test
				if (cg.goalTest[0] == 0 && cg.goalTest[2] == 0)
					return node;

				if (node.depth < depth) {
					String hash = state.stateToString();

					// Adding nodes to the queue
					if (!contains(visitedStates, hash)) {
						visitedStates.add(hash);

						CoastGuard newCG = new CoastGuard(currCell[0], currCell[1], remainingPass, cg.maxNoOfPass,
								cg.goalTest, remainingAlivePass);
						AgentState newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);

						if (s != null && !s.blackBoxRetrieved && remainingPass != 0) { // current Node is a ship
							if (s.remainingPassengers > 0) {
								Node n = new Node(newState, node.depth + 1, node, "pickup", node.cost + 1);
								if (n.depth <= depth)
									stack.add(n);
							} else if (!s.blackBoxRetrieved && s.blackBoxTimeRemaining > 0) {
								Node n = new Node(newState, node.depth + 1, node, "retrieve", node.cost + 1);
								if (n.depth <= depth)
									stack.add(n);
							}

						} else if (st == true && remainingPass < cg.maxNoOfPass) {
							Node n = new Node(newState, node.depth + 1, node, "drop", node.cost + 1);
							if (n.depth <= depth)
								stack.add(n);
						}

						else {
							if (currCell[0] > 0) {
								newCG = new CoastGuard(currCell[0] - 1, currCell[1], remainingPass, cg.maxNoOfPass,
										cg.goalTest, remainingAlivePass);
								newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
								Node n = new Node(newState, node.depth + 1, node, "up", node.cost + 1);
								if (n.depth <= depth)
									stack.add(n);
							}

							if (currCell[0] < (gridArr.length - 1)) {
								newCG = new CoastGuard(currCell[0] + 1, currCell[1], remainingPass, cg.maxNoOfPass,
										cg.goalTest, remainingAlivePass);
								newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
								Node n = new Node(newState, node.depth + 1, node, "down", node.cost + 1);
								if (n.depth <= depth)
									stack.add(n);
							}

							if (currCell[1] > 0) {
								newCG = new CoastGuard(currCell[0], currCell[1] - 1, remainingPass, cg.maxNoOfPass,
										cg.goalTest, remainingAlivePass);
								newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
								Node n = new Node(newState, node.depth + 1, node, "left", node.cost + 1);
								if (n.depth <= depth)
									stack.add(n);
							}

							if (currCell[1] < (gridArr[0].length - 1)) {
								newCG = new CoastGuard(currCell[0], currCell[1] + 1, remainingPass, cg.maxNoOfPass,
										cg.goalTest, remainingAlivePass);
								newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
								Node n = new Node(newState, node.depth + 1, node, "right", node.cost + 1);
								if (n.depth <= depth)
									stack.add(n);
							}
						}

					}

				}
			}

		}
	}

	public static Node GR1(String grid) {
		CoastGuard coastGuard = new CoastGuard();
		PriorityQueue<Node> queue = new PriorityQueue<Node>(1, new Comparator<Node>() {
			public int compare(Node node1, Node node2) {
				if (node1.cost < node2.cost)
					return -1;
				if (node1.cost > node2.cost)
					return 1;
				return 0;
			}
		});
		queue.add(InitializeCoastGuard(coastGuard, grid));
		ArrayList<String> visitedStates = new ArrayList<String>();

		while (!queue.isEmpty()) {
			Node node = queue.remove();
			AgentState state = node.state;
			CoastGuard cg = state.coastGuard;
			int[] currCell = cg.cell;
			int savedPass = state.safePassengers;
			int remainingPass = cg.remainingPass;
			int deadPass = state.deadPassengers;
			int blackBoxRetrieved = state.boxesRetrieved;
			int remainingAlivePass = cg.remainingAlivePass;

			// Check if the cell is a ship or a station or neither
			boolean st = false;

			if (gridArr[currCell[0]][currCell[1]] instanceof Station)
				st = true;

			if (node.operator != null) {
				if (node.operator.equals("pickup")) {
					int x = pickup(state, cg, currCell);
					savedPass += x;
					remainingPass -= x;
					remainingAlivePass -= x;
				}
				if (node.operator.equals("drop")) {
					cg.goalTest[0] = 0;
					remainingPass = cg.maxNoOfPass;
				}
				if (node.operator.equals("retrieve")) {
					int index = getShip(state.wreckedShips, currCell);
					if (index != -1) {
						Ship ship = state.wreckedShips.get(index);
						ship.blackBoxRetrieved = true;
						cg.goalTest[2]--;
						state.boxesRetrieved += 1;
					}
					blackBoxRetrieved += 1;
				}
			}

			Ship s = null;

			// Handling the loss of a passenger every step
			ArrayList<Ship> safeShips = clone(state.safeShips);
			ArrayList<Ship> wreckedShips = clone(state.wreckedShips);

			if (node.parentNode != null) {
				ArrayList<Ship> newWrecked = new ArrayList<Ship>();
				for (int i = 0; i < safeShips.size(); i++) {
					Ship ship = safeShips.get(i);
					if(ship.remainingPassengers > 0)
					{
						ship.remainingPassengers -= 1;
						deadPass += 1;
						remainingAlivePass -= 1;
					}
					
					if(ship.remainingPassengers == 0)
					{
						ship.blackBoxTimeRemaining-=1;
						newWrecked.add(ship);
					}

					if (ship.getX() == currCell[0] && ship.getY() == currCell[1]) {
						s = ship;
					}
				}

				safeShips.removeAll(newWrecked);

				for (int i = 0; i < wreckedShips.size(); i++) {
					Ship ship = wreckedShips.get(i);

					if (!ship.blackBoxRetrieved && ship.blackBoxTimeRemaining == 1) {
						cg.goalTest[2]--;
						ship.blackBoxTimeRemaining -= 1;
					}

					if (!ship.blackBoxRetrieved && ship.blackBoxTimeRemaining > 0)
						ship.blackBoxTimeRemaining -= 1;

					if (!ship.blackBoxRetrieved && ship.blackBoxTimeRemaining > 0 && ship.getX() == currCell[0]
							&& ship.getY() == currCell[1])
						s = ship;
				}

				wreckedShips.addAll(newWrecked);

			}

			// Check if we reached the goal test
			if (cg.goalTest[0] == 0 && cg.goalTest[2] == 0)
				return node;

			String hash = state.stateToString();

			// Adding nodes to the queue
			if (!contains(visitedStates, hash) || (node.operator.equals("retrieve"))) {
				visitedStates.add(hash);

				CoastGuard newCG = new CoastGuard(currCell[0], currCell[1], remainingPass, cg.maxNoOfPass, cg.goalTest,
						remainingAlivePass);
				AgentState newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);

				if (s != null && !s.blackBoxRetrieved && s.blackBoxTimeRemaining > 0) { // current Node is a ship
					if (s.remainingPassengers > 0 && remainingPass > 0) {
						queue.add(new Node(newState, node.depth + 1, node, "pickup", safeShips.size() - 1));
					} else if (s.remainingPassengers == 0 && !s.blackBoxRetrieved && s.blackBoxTimeRemaining > 0) {
						queue.add(new Node(newState, node.depth + 1, node, "retrieve", safeShips.size() - 1));
					}

				} else if (st == true && remainingPass < cg.maxNoOfPass) {
					queue.add(new Node(newState, node.depth + 1, node, "drop", safeShips.size() - 1));
				}

				else {
					if (currCell[0] > 0) {
						newCG = new CoastGuard(currCell[0] - 1, currCell[1], remainingPass, cg.maxNoOfPass, cg.goalTest,
								remainingAlivePass);
						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
						queue.add(new Node(newState, node.depth + 1, node, "up", safeShips.size() - 1));
					}

					if (currCell[0] < (gridArr.length - 1)) {
						newCG = new CoastGuard(currCell[0] + 1, currCell[1], remainingPass, cg.maxNoOfPass, cg.goalTest,
								remainingAlivePass);
						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
						queue.add(new Node(newState, node.depth + 1, node, "down", safeShips.size() - 1));
					}

					if (currCell[1] > 0) {
						newCG = new CoastGuard(currCell[0], currCell[1] - 1, remainingPass, cg.maxNoOfPass, cg.goalTest,
								remainingAlivePass);
						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
						queue.add(new Node(newState, node.depth + 1, node, "left", safeShips.size() - 1));
					}

					if (currCell[1] < (gridArr[0].length - 1)) {
						newCG = new CoastGuard(currCell[0], currCell[1] + 1, remainingPass, cg.maxNoOfPass, cg.goalTest,
								remainingAlivePass);
						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
						queue.add(new Node(newState, node.depth + 1, node, "right", safeShips.size() - 1));
					}
				}

			}

		}

		return null;

	}

	public static Node GR2(String grid) {
		CoastGuard coastGuard = new CoastGuard();
		PriorityQueue<Node> queue = new PriorityQueue<Node>(1, new Comparator<Node>() {
			public int compare(Node node1, Node node2) {
				if (node1.cost < node2.cost)
					return -1;
				if (node1.cost > node2.cost)
					return 1;
				return 0;
			}
		});
		queue.add(InitializeCoastGuard(coastGuard, grid));
		ArrayList<String> visitedStates = new ArrayList<String>();

		while (!queue.isEmpty()) {
			Node node = queue.remove();
			AgentState state = node.state;
			CoastGuard cg = state.coastGuard;
			int[] currCell = cg.cell;
			int savedPass = state.safePassengers;
			int remainingPass = cg.remainingPass;
			int deadPass = state.deadPassengers;
			int blackBoxRetrieved = state.boxesRetrieved;
			int remainingAlivePass = cg.remainingAlivePass;
			int cost = 0;

			// Check if the cell is a ship or a station or neither
			boolean st = false;

			if (gridArr[currCell[0]][currCell[1]] instanceof Station)
				st = true;

			if (node.operator != null) {
				if (node.operator.equals("pickup")) {
					int x = pickup(state, cg, currCell);
					savedPass += x;
					remainingPass -= x;
					remainingAlivePass -= x;
				}
				if (node.operator.equals("drop")) {
					cg.goalTest[0] = 0;
					remainingPass = cg.maxNoOfPass;
				}
				if (node.operator.equals("retrieve")) {
					int index = getShip(state.wreckedShips, currCell);
					if (index != -1) {
						Ship ship = state.wreckedShips.get(index);
						ship.blackBoxRetrieved = true;
						cg.goalTest[2]--;
						state.boxesRetrieved += 1;
					}
					blackBoxRetrieved += 1;
				}
			}

			Ship s = null;

			// Handling the loss of a passenger every step
			ArrayList<Ship> safeShips = clone(state.safeShips);
			ArrayList<Ship> wreckedShips = clone(state.wreckedShips);

			if (node.parentNode != null) {
				ArrayList<Ship> newWrecked = new ArrayList<Ship>();
				for (int i = 0; i < safeShips.size(); i++) {
					Ship ship = safeShips.get(i);
					if(ship.remainingPassengers > 0)
					{
						ship.remainingPassengers -= 1;
						deadPass += 1;
						remainingAlivePass -= 1;
					}
					
					if(ship.remainingPassengers == 0)
					{
						ship.blackBoxTimeRemaining-=1;
						newWrecked.add(ship);
					}

					if (ship.getX() == currCell[0] && ship.getY() == currCell[1]) {
						s = ship;
					}
					
					cost += (int)Math.ceil((double) ship.remainingPassengers / cg.maxNoOfPass);

				}

				safeShips.removeAll(newWrecked);

				for (int i = 0; i < wreckedShips.size(); i++) {
					Ship ship = wreckedShips.get(i);

					if (!ship.blackBoxRetrieved && ship.blackBoxTimeRemaining == 1) {
						cg.goalTest[2]--;
						ship.blackBoxTimeRemaining -= 1;
					}

					if (!ship.blackBoxRetrieved && ship.blackBoxTimeRemaining > 0)
						ship.blackBoxTimeRemaining -= 1;

					if (!ship.blackBoxRetrieved && ship.blackBoxTimeRemaining > 0 && ship.getX() == currCell[0]
							&& ship.getY() == currCell[1])
						s = ship;
				}

				wreckedShips.addAll(newWrecked);

			}

			// Check if we reached the goal test
			if (cg.goalTest[0] == 0 && cg.goalTest[2] == 0)
				return node;

			String hash = state.stateToString();

			// Adding nodes to the queue
			if (!contains(visitedStates, hash) || (node.operator.equals("retrieve"))) {
				visitedStates.add(hash);

				CoastGuard newCG = new CoastGuard(currCell[0], currCell[1], remainingPass, cg.maxNoOfPass, cg.goalTest,
						remainingAlivePass);
				AgentState newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);

				if (s != null && !s.blackBoxRetrieved && s.blackBoxTimeRemaining > 0) { // current Node is a ship
					if (s.remainingPassengers > 0 && remainingPass > 0) {
						queue.add(new Node(newState, node.depth + 1, node, "pickup", cost));
					} else if (s.remainingPassengers == 0 && !s.blackBoxRetrieved && s.blackBoxTimeRemaining > 0) {
						queue.add(new Node(newState, node.depth + 1, node, "retrieve", cost));
					}

				} else if (st == true && remainingPass < cg.maxNoOfPass) {
					queue.add(new Node(newState, node.depth + 1, node, "drop", cost));
				}

				else {
					if (currCell[0] > 0) {
						newCG = new CoastGuard(currCell[0] - 1, currCell[1], remainingPass, cg.maxNoOfPass, cg.goalTest,
								remainingAlivePass);
						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
						queue.add(new Node(newState, node.depth + 1, node, "up", cost));
					}

					if (currCell[0] < (gridArr.length - 1)) {
						newCG = new CoastGuard(currCell[0] + 1, currCell[1], remainingPass, cg.maxNoOfPass, cg.goalTest,
								remainingAlivePass);
						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
						queue.add(new Node(newState, node.depth + 1, node, "down", cost));
					}

					if (currCell[1] > 0) {
						newCG = new CoastGuard(currCell[0], currCell[1] - 1, remainingPass, cg.maxNoOfPass, cg.goalTest,
								remainingAlivePass);
						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
						queue.add(new Node(newState, node.depth + 1, node, "left", cost));
					}

					if (currCell[1] < (gridArr[0].length - 1)) {
						newCG = new CoastGuard(currCell[0], currCell[1] + 1, remainingPass, cg.maxNoOfPass, cg.goalTest,
								remainingAlivePass);
						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
						queue.add(new Node(newState, node.depth + 1, node, "right", cost));
					}
				}

			}

		}

		return null;

	}

	public static Node AS1(String grid) {
		CoastGuard coastGuard = new CoastGuard();
		PriorityQueue<Node> queue = new PriorityQueue<Node>(1, new Comparator<Node>() {
			public int compare(Node node1, Node node2) {
				if (node1.cost < node2.cost)
					return -1;
				if (node1.cost > node2.cost)
					return 1;
				return 0;
			}
		});
		queue.add(InitializeCoastGuard(coastGuard, grid));
		ArrayList<String> visitedStates = new ArrayList<String>();

		while (!queue.isEmpty()) {
			Node node = queue.remove();
			AgentState state = node.state;
			CoastGuard cg = state.coastGuard;
			int[] currCell = cg.cell;
			int savedPass = state.safePassengers;
			int remainingPass = cg.remainingPass;
			int deadPass = state.deadPassengers;
			int blackBoxRetrieved = state.boxesRetrieved;
			int remainingAlivePass = cg.remainingAlivePass;

			// Check if the cell is a ship or a station or neither
			boolean st = false;

			if (gridArr[currCell[0]][currCell[1]] instanceof Station)
				st = true;

			if (node.operator != null) {
				if (node.operator.equals("pickup")) {
					int x = pickup(state, cg, currCell);
					savedPass += x;
					remainingPass -= x;
					remainingAlivePass -= x;
				}
				if (node.operator.equals("drop")) {
					cg.goalTest[0] = 0;
					remainingPass = cg.maxNoOfPass;
				}
				if (node.operator.equals("retrieve")) {
					int index = getShip(state.wreckedShips, currCell);
					if (index != -1) {
						Ship ship = state.wreckedShips.get(index);
						ship.blackBoxRetrieved = true;
						cg.goalTest[2]--;
						state.boxesRetrieved += 1;
					}
					blackBoxRetrieved += 1;
				}
			}

			Ship s = null;

			// Handling the loss of a passenger every step
			ArrayList<Ship> safeShips = clone(state.safeShips);
			ArrayList<Ship> wreckedShips = clone(state.wreckedShips);

			if (node.parentNode != null) {
				ArrayList<Ship> newWrecked = new ArrayList<Ship>();
				for (int i = 0; i < safeShips.size(); i++) {
					Ship ship = safeShips.get(i);
					if(ship.remainingPassengers > 0)
					{
						ship.remainingPassengers -= 1;
						deadPass += 1;
						remainingAlivePass -= 1;
					}
					
					if(ship.remainingPassengers == 0)
					{
						ship.blackBoxTimeRemaining-=1;
						newWrecked.add(ship);
					}

					if (ship.getX() == currCell[0] && ship.getY() == currCell[1]) {
						s = ship;
					}
				}

				safeShips.removeAll(newWrecked);

				for (int i = 0; i < wreckedShips.size(); i++) {
					Ship ship = wreckedShips.get(i);

					if (!ship.blackBoxRetrieved && ship.blackBoxTimeRemaining == 1) {
						cg.goalTest[2]--;
						ship.blackBoxTimeRemaining -= 1;
					}

					if (!ship.blackBoxRetrieved && ship.blackBoxTimeRemaining > 0)
						ship.blackBoxTimeRemaining -= 1;

					if (!ship.blackBoxRetrieved && ship.blackBoxTimeRemaining > 0 && ship.getX() == currCell[0]
							&& ship.getY() == currCell[1])
						s = ship;
				}

				wreckedShips.addAll(newWrecked);

			}

			// Check if we reached the goal test
			if (cg.goalTest[0] == 0 && cg.goalTest[2] == 0)
				return node;

			String hash = state.stateToString();

			// Adding nodes to the queue
			//The path cost is always the deoth of the node 
			if (!contains(visitedStates, hash) || (node.operator.equals("retrieve"))) {
				visitedStates.add(hash);

				CoastGuard newCG = new CoastGuard(currCell[0], currCell[1], remainingPass, cg.maxNoOfPass, cg.goalTest,
						remainingAlivePass);
				AgentState newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);

				if (s != null && !s.blackBoxRetrieved && s.blackBoxTimeRemaining > 0) { // current Node is a ship
					if (s.remainingPassengers > 0 && remainingPass > 0) {
						queue.add(new Node(newState, node.depth + 1, node, "pickup", safeShips.size() - 1 + node.depth + 1));
					} else if (s.remainingPassengers == 0 && !s.blackBoxRetrieved && s.blackBoxTimeRemaining > 0) {
						queue.add(new Node(newState, node.depth + 1, node, "retrieve", safeShips.size() - 1 + node.depth + 1));
					}

				} else if (st == true && remainingPass < cg.maxNoOfPass) {
					queue.add(new Node(newState, node.depth + 1, node, "drop", safeShips.size() - 1 + node.depth + 1));
				}

				else {
					if (currCell[0] > 0) {
						newCG = new CoastGuard(currCell[0] - 1, currCell[1], remainingPass, cg.maxNoOfPass, cg.goalTest,
								remainingAlivePass);
						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
						queue.add(new Node(newState, node.depth + 1, node, "up", safeShips.size() - 1 + node.depth + 1));
					}

					if (currCell[0] < (gridArr.length - 1)) {
						newCG = new CoastGuard(currCell[0] + 1, currCell[1], remainingPass, cg.maxNoOfPass, cg.goalTest,
								remainingAlivePass);
						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
						queue.add(new Node(newState, node.depth + 1, node, "down", safeShips.size() - 1 + node.depth + 1));
					}

					if (currCell[1] > 0) {
						newCG = new CoastGuard(currCell[0], currCell[1] - 1, remainingPass, cg.maxNoOfPass, cg.goalTest,
								remainingAlivePass);
						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
						queue.add(new Node(newState, node.depth + 1, node, "left", safeShips.size() - 1 + node.depth + 1));
					}

					if (currCell[1] < (gridArr[0].length - 1)) {
						newCG = new CoastGuard(currCell[0], currCell[1] + 1, remainingPass, cg.maxNoOfPass, cg.goalTest,
								remainingAlivePass);
						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
						queue.add(new Node(newState, node.depth + 1, node, "right", safeShips.size() - 1 + node.depth + 1));
					}
				}

			}

		}

		return null;

	}
	
	public static Node AS2(String grid) {
		CoastGuard coastGuard = new CoastGuard();
		PriorityQueue<Node> queue = new PriorityQueue<Node>(1, new Comparator<Node>() {
			public int compare(Node node1, Node node2) {
				if (node1.cost < node2.cost)
					return -1;
				if (node1.cost > node2.cost)
					return 1;
				return 0;
			}
		});
		queue.add(InitializeCoastGuard(coastGuard, grid));
		ArrayList<String> visitedStates = new ArrayList<String>();

		while (!queue.isEmpty()) {
			Node node = queue.remove();
			AgentState state = node.state;
			CoastGuard cg = state.coastGuard;
			int[] currCell = cg.cell;
			int savedPass = state.safePassengers;
			int remainingPass = cg.remainingPass;
			int deadPass = state.deadPassengers;
			int blackBoxRetrieved = state.boxesRetrieved;
			int remainingAlivePass = cg.remainingAlivePass;
			int cost = 0;

			// Check if the cell is a ship or a station or neither
			boolean st = false;

			if (gridArr[currCell[0]][currCell[1]] instanceof Station)
				st = true;

			if (node.operator != null) {
				if (node.operator.equals("pickup")) {
					int x = pickup(state, cg, currCell);
					savedPass += x;
					remainingPass -= x;
					remainingAlivePass -= x;
				}
				if (node.operator.equals("drop")) {
					cg.goalTest[0] = 0;
					remainingPass = cg.maxNoOfPass;
				}
				if (node.operator.equals("retrieve")) {
					int index = getShip(state.wreckedShips, currCell);
					if (index != -1) {
						Ship ship = state.wreckedShips.get(index);
						ship.blackBoxRetrieved = true;
						cg.goalTest[2]--;
						state.boxesRetrieved += 1;
					}
					blackBoxRetrieved += 1;
				}
			}

			Ship s = null;

			// Handling the loss of a passenger every step
			ArrayList<Ship> safeShips = clone(state.safeShips);
			ArrayList<Ship> wreckedShips = clone(state.wreckedShips);

			if (node.parentNode != null) {
				ArrayList<Ship> newWrecked = new ArrayList<Ship>();
				for (int i = 0; i < safeShips.size(); i++) {
					Ship ship = safeShips.get(i);
					if(ship.remainingPassengers > 0)
					{
						ship.remainingPassengers -= 1;
						deadPass += 1;
						remainingAlivePass -= 1;
					}
					
					if(ship.remainingPassengers == 0)
					{
						ship.blackBoxTimeRemaining-=1;
						newWrecked.add(ship);
					}

					if (ship.getX() == currCell[0] && ship.getY() == currCell[1]) {
						s = ship;
					}
					
					cost += (int)Math.ceil((double) ship.remainingPassengers / cg.maxNoOfPass);
				}

				safeShips.removeAll(newWrecked);

				for (int i = 0; i < wreckedShips.size(); i++) {
					Ship ship = wreckedShips.get(i);

					if (!ship.blackBoxRetrieved && ship.blackBoxTimeRemaining == 1) {
						cg.goalTest[2]--;
						ship.blackBoxTimeRemaining -= 1;
					}

					if (!ship.blackBoxRetrieved && ship.blackBoxTimeRemaining > 0)
						ship.blackBoxTimeRemaining -= 1;

					if (!ship.blackBoxRetrieved && ship.blackBoxTimeRemaining > 0 && ship.getX() == currCell[0]
							&& ship.getY() == currCell[1])
						s = ship;
				}

				wreckedShips.addAll(newWrecked);

			}

			// Check if we reached the goal test
			if (cg.goalTest[0] == 0 && cg.goalTest[2] == 0)
				return node;

			String hash = state.stateToString();

			// Adding nodes to the queue
			if (!contains(visitedStates, hash) || (node.operator.equals("retrieve"))) {
				visitedStates.add(hash);

				CoastGuard newCG = new CoastGuard(currCell[0], currCell[1], remainingPass, cg.maxNoOfPass, cg.goalTest,
						remainingAlivePass);
				AgentState newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);

				if (s != null && !s.blackBoxRetrieved && s.blackBoxTimeRemaining > 0) { // current Node is a ship
					if (s.remainingPassengers > 0 && remainingPass > 0) {
						queue.add(new Node(newState, node.depth + 1, node, "pickup", cost + node.depth + 1));
					} else if (s.remainingPassengers == 0 && !s.blackBoxRetrieved && s.blackBoxTimeRemaining > 0) {
						queue.add(new Node(newState, node.depth + 1, node, "retrieve", cost + node.depth + 1));
					}

				} else if (st == true && remainingPass < cg.maxNoOfPass) {
					queue.add(new Node(newState, node.depth + 1, node, "drop", cost + node.depth + 1));
				}

				else {
					if (currCell[0] > 0) {
						newCG = new CoastGuard(currCell[0] - 1, currCell[1], remainingPass, cg.maxNoOfPass, cg.goalTest,
								remainingAlivePass);
						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
						queue.add(new Node(newState, node.depth + 1, node, "up", cost + node.depth + 1));
					}

					if (currCell[0] < (gridArr.length - 1)) {
						newCG = new CoastGuard(currCell[0] + 1, currCell[1], remainingPass, cg.maxNoOfPass, cg.goalTest,
								remainingAlivePass);
						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
						queue.add(new Node(newState, node.depth + 1, node, "down", cost + node.depth + 1));
					}

					if (currCell[1] > 0) {
						newCG = new CoastGuard(currCell[0], currCell[1] - 1, remainingPass, cg.maxNoOfPass, cg.goalTest,
								remainingAlivePass);
						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
						queue.add(new Node(newState, node.depth + 1, node, "left", cost + node.depth + 1));
					}

					if (currCell[1] < (gridArr[0].length - 1)) {
						newCG = new CoastGuard(currCell[0], currCell[1] + 1, remainingPass, cg.maxNoOfPass, cg.goalTest,
								remainingAlivePass);
						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
						queue.add(new Node(newState, node.depth + 1, node, "right", cost + node.depth + 1));
					}
				}

			}

		}

		return null;

	}

	public static int pickup(AgentState state, CoastGuard cg, int[] cell) {

		int index = getShip(state.safeShips, cell);
		int savedPass = 0;
		if (index != -1) {
			Ship ship = state.safeShips.get(index);
			if (ship.remainingPassengers > 0 && ship.remainingPassengers <= cg.remainingPass) {
				savedPass += ship.remainingPassengers;
				cg.goalTest[0] += ship.remainingPassengers;
				ship.remainingPassengers = 0;
			} else if (ship.remainingPassengers > cg.remainingPass) {
				savedPass += cg.remainingPass;
				cg.goalTest[0] += cg.remainingPass;
				ship.remainingPassengers -= cg.remainingPass;
			}
		}

		return savedPass;

	}

	public static int getShip(ArrayList<Ship> ships, int[] cell) {

		for (int i = 0; i < ships.size(); i++) {
			if (ships.get(i).getX() == cell[0] && ships.get(i).getY() == cell[1])
				return i;
		}

		return -1;
	}

	public static Node InitializeCoastGuard(CoastGuard coastGuard, String grid) {
		String[] gridArray = grid.split(";");

		// Grid size
		String[] GS = gridArray[0].split(",");

		gridArr = new Object[Integer.parseInt(GS[1])][Integer.parseInt(GS[0])];

		coastGuard.maxNoOfPass = Integer.parseInt(gridArray[1]);
		coastGuard.remainingPass = Integer.parseInt(gridArray[1]);
		coastGuard.goalTest[0] = 0; // No of passengers on board

		// Coast Guard's Initial State
		coastGuard.initialState = new int[2];
		String[] GuardCell = gridArray[2].split(",");
		coastGuard.cell[0] = Integer.parseInt(GuardCell[0]);
		coastGuard.cell[1] = Integer.parseInt(GuardCell[1]);
		coastGuard.initialState[0] = Integer.parseInt(GuardCell[0]);
		coastGuard.initialState[1] = Integer.parseInt(GuardCell[1]);

		String[] st = gridArray[3].split(",");
		stations = new ArrayList<Station>();
		for (int i = 0; i <= st.length / 2; i += 2) {
			int x = Integer.parseInt(st[i]);
			int y = Integer.parseInt(st[i + 1]);
			Station s = new Station(x, y);
			stations.add(s);

			gridArr[x][y] = s;
		}

		int sumOfPass = 0;
		String[] sh = gridArray[4].split(",");
		ArrayList<Ship> ships = new ArrayList<Ship>();
		for (int i = 2; i < sh.length; i += 3) {
			int x = Integer.parseInt(sh[i - 2]);
			int y = Integer.parseInt(sh[i - 1]);
			int maxP = Integer.parseInt(sh[i]);
			sumOfPass += maxP;
			ships.add(new Ship(x, y, maxP));
		}

		coastGuard.remainingAlivePass = sumOfPass;
		coastGuard.goalTest[1] = sumOfPass;
		coastGuard.goalTest[2] = ships.size();
		coastGuard.noOfShips = ships.size();

		AgentState currentState = new AgentState(coastGuard, ships);

		Node initialNode = new Node(currentState, 0, null, null, 0);

		return initialNode;
	}

	
	
	public static String GenGrid() {
		String result = "";
		int min = 5;
		int max = 15;

		// m should be greater than or equal to 5
		// n should be less than or equal to 15

		int m = (int) Math.floor(Math.random() * (max - min + 1) + min); // min <= m <= max
		int n = (int) Math.floor(Math.random() * (max - min + 1) + min);

		Cell[][] grid = new Cell[m][n];

		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				// Cell c = new Cell();
				grid[i][j] = new Cell(m,n);
				grid[i][j].setX(i);
				grid[i][j].setY(j);
			}

		}
		
		int c = (int) Math.floor(Math.random()*(100-30+1)+30);
		Agent agent = new Agent(c);

		// initial position of the agent
		int cgX = (int) Math.floor(Math.random() * m);
		int cgY = (int) Math.floor(Math.random() * n);

		agent.setX(cgX);
		agent.setY(cgY);

		grid[cgX][cgY].setEmpty(false);
//		grid[cgX][cgY].setAgent(true);
		grid[cgX][cgY].setX(cgX);
		grid[cgX][cgY].setY(cgY);

		// M,N;C;cgX,cgY;
		result = "" + m + "," + n + ";" + agent.getC() + ";" + cgX + "," + cgY + ";";
		result += "\n";

		// 1 -> 15?
		int numberOfStations = (int) Math.floor(Math.random() * ((m * n - 2)) + 1);
		int countStation = 0;
		while (countStation < numberOfStations) {
			int stationX = (int) Math.floor(Math.random() * (m));
			int stationY = (int) Math.floor(Math.random() * (n));

			if (grid[stationX][stationY].isEmpty()) { // empty cell -> can insert station in this cell
				grid[stationX][stationY].setEmpty(false);
				grid[stationX][stationY].setStation(true);
				grid[stationX][stationY].setX(stationX);
				grid[stationX][stationY].setY(stationY);

				if (countStation == numberOfStations - 1) {
					result += stationX + "," + stationY + ";";
				} else {
					result += stationX + "," + stationY + ",";
				}

				countStation++;
			}
		}

		result += "\n";

		int numberOfShips = (int) Math.floor(Math.random() * ((m * n) - numberOfStations - 1) + 1);
		int countShip = 0;
		while (countShip < numberOfShips) {
			int shipX = (int) Math.floor(Math.random() * (m));
			int shipY = (int) Math.floor(Math.random() * (n));

			if (grid[shipX][shipY].isEmpty()) { // empty cell -> can insert ship in this cell
				grid[shipX][shipY].setEmpty(false);
				grid[shipX][shipY].setShip(true);
				grid[shipX][shipY].setX(shipX);
				grid[shipX][shipY].setY(shipY);

				Ship sh = new Ship();
				sh.setX(shipX);
				sh.setY(shipY);
				
				
				//===========================================
//				remainingPassengers = sh.getP();
				
//				ships.add(sh);

				if (countShip == numberOfShips - 1) {
					result += shipX + "," + shipY + ";";
				} else {
					result += shipX + "," + shipY + ",";
				}

				countShip++;
			}
		}

		return result;
	}
	
	
	
	public static void print(Object o) {
		System.out.println(o);
	}
	
	
	public static AgentState moveUp(AgentState oldState , boolean id) throws CloneNotSupportedException {
		int deaths= oldState.deadPassengers;
		
		AgentState newState = null;
		ArrayList<Ship> temp = new ArrayList<Ship>();

		if (oldState.agentX != 0) {
//			System.out.println("MOVE UP");
			ArrayList<String> actions = actionsClone(oldState.actions);
			actions.add("up");

			for (int i=0; i < oldState.ships.size(); i++) {
				temp.add(shipClone((Ship)oldState.ships.get(i)));
			}
			
			if(id && oldState.operator != "down") {
				System.out.println("old state depth before creating new state: "+ oldState.depth);
				newState = new AgentState(xClone(oldState.agentX)-1, yClone(oldState.agentY), oldState.passengersOnBoard, oldState.boxesRetrieved, oldState.ships, "up", actions, depthClone(oldState.depth)+1 ,deaths);
				System.out.println("old state depth after creating new state: "+ oldState.depth);
				System.out.println("new state depth: "+ newState.depth);
			}
			
			if (!id) {
				newState = new AgentState(xClone(oldState.agentX)-1, yClone(oldState.agentY), oldState.passengersOnBoard, oldState.boxesRetrieved, oldState.ships, "up", actions,deaths);
			}

			if(newState != null) {
				for (int k=0 ; k < newState.ships.size() ; k++) {
					if (newState.ships.get(k).getP() > 0) {
						remainingPassengers--;
						deaths ++;
//						totalDeaths++;
						newState.ships.get(k).damage();
					}
					
					
				}
				newState.deadPassengers = deaths;
			}
			
		}
		return newState;
	}
	
	public static AgentState moveDown(AgentState oldState, boolean id) throws CloneNotSupportedException {
		int deaths = oldState.deadPassengers;
		
		AgentState newState = null;
		ArrayList<Ship> temp = new ArrayList<Ship>();
		
		if (oldState.agentX < m-1) {
			
//			System.out.println(oldState.agentX+","+oldState.agentY);
			
//			System.out.println("MOVE DOWN");

			ArrayList<String> actions = actionsClone(oldState.actions);
			actions.add("down");
			
			for (int i=0; i < oldState.ships.size(); i++) {
				temp.add(shipClone((Ship)oldState.ships.get(i)));
				
			}
			
			if(id && oldState.operator != "up") {
				System.out.println("old state depth before creating new state: "+ oldState.depth);
				newState = new AgentState(xClone(oldState.agentX)+1, yClone(oldState.agentY), oldState.passengersOnBoard, oldState.boxesRetrieved, oldState.ships, "down", actions, depthClone(oldState.depth)+1 , deaths);
				System.out.println("old state depth after creating new state: "+ oldState.depth);
				System.out.println("new state depth: "+ newState.depth);
			}
			
			if(!id) {
				newState = new AgentState(xClone(oldState.agentX)+1, yClone(oldState.agentY), oldState.passengersOnBoard, oldState.boxesRetrieved, oldState.ships, "down", actions, deaths);
			}			
			
			
			if(newState != null) {
				for (int k=0 ; k < newState.ships.size() ; k++) {
					
					if (newState.ships.get(k).getP() > 0) {
						remainingPassengers--;
						deaths ++;
//						totalDeaths++;
						newState.ships.get(k).damage();
					}
					
				}
				newState.deadPassengers = deaths;
			}
		}
		
		return newState;
	}
	
	public static AgentState moveRight(AgentState oldState, boolean id) throws CloneNotSupportedException {
		int deaths = oldState.deadPassengers;
		
		AgentState newState = null;
		ArrayList<Ship> temp = new ArrayList<Ship>();

		if (oldState.agentY < n-1) {
//			System.out.println("MOVE RIGHT");
			ArrayList<String> actions = actionsClone(oldState.actions);
			actions.add("right");
			
			for (int i=0; i < oldState.ships.size(); i++) {
				temp.add(shipClone((Ship)oldState.ships.get(i)));
				
			}
			
			if(id && oldState.operator != "left") {
				System.out.println("old state depth before creating new state: "+ oldState.depth);
				newState = new AgentState(xClone(oldState.agentX), yClone(oldState.agentY)+1, oldState.passengersOnBoard, oldState.boxesRetrieved, oldState.ships, "right", actions, depthClone(oldState.depth)+1, deaths);
				System.out.println("old state depth after creating new state: "+ oldState.depth);
				System.out.println("new state depth: "+ newState.depth);	
			}
			
			if(!id) {
				newState = new AgentState(xClone(oldState.agentX), yClone(oldState.agentY)+1, oldState.passengersOnBoard, oldState.boxesRetrieved, oldState.ships, "right", actions, deaths);
			}
			
			if(newState != null) {
				for (int k=0 ; k < newState.ships.size() ; k++) {
					
					if (newState.ships.get(k).getP() > 0) {
						remainingPassengers--;
						deaths ++;
//						totalDeaths++;
						newState.ships.get(k).damage();
					}
					
					
				}
				newState.deadPassengers = deaths;
			}

		}
		
		return newState;
	}
	
	public static AgentState moveLeft(AgentState oldState, boolean id) throws CloneNotSupportedException {
		int deaths= oldState.deadPassengers;
		
		AgentState newState = null;
		ArrayList<Ship> temp = new ArrayList<Ship>();
		
		if (oldState.agentY != 0) {		
//			System.out.println("MOVE LEFT");

			ArrayList<String> actions = actionsClone(oldState.actions);
			actions.add("left");
			
			for (int i=0; i < oldState.ships.size(); i++) {
				temp.add(shipClone((Ship)oldState.ships.get(i)));
				
			}
			
			if(id && oldState.operator != "right") {
				System.out.println("old state depth before creating new state: "+ oldState.depth);
				newState = new AgentState(xClone(oldState.agentX), yClone(oldState.agentY)-1, oldState.passengersOnBoard, oldState.boxesRetrieved, oldState.ships, "left", actions, depthClone(oldState.depth)+1 , deaths);
				System.out.println("old state depth after creating new state: "+ oldState.depth);
				System.out.println("new state depth: "+ newState.depth);
			}
			
			if(!id) {
				newState = new AgentState(xClone(oldState.agentX), yClone(oldState.agentY)-1, oldState.passengersOnBoard, oldState.boxesRetrieved, oldState.ships, "left", actions, deaths);
			}
			
			if(newState != null) {
				for (int k=0 ; k < newState.ships.size() ; k++) {
					
					if (newState.ships.get(k).getP() > 0) {
						remainingPassengers--;
						deaths ++;
//						totalDeaths++;
						newState.ships.get(k).damage();
					}
					
				
				}
				newState.deadPassengers = deaths;
			}
		}
		
		
		return newState;
	}
	
	
	public static AgentState pickup(AgentState oldState, Ship ship, boolean id) throws CloneNotSupportedException{
		int deaths = oldState.deadPassengers;
		
		AgentState newState = null;
		boolean canPickup = false;
		ArrayList<Ship> temp = new ArrayList<Ship>();

		int index = 0;
		int d = 0;
		
		ArrayList<String> actions = actionsClone(oldState.actions);
		
		int count = passengersOnBoardClone(oldState.passengersOnBoard);
		
		for (int i=0; i < oldState.ships.size(); i++) {
			temp.add(shipClone((Ship)oldState.ships.get(i)));	
		}

		while (count <= agent.getC() && ship.getP() > 0) {
				canPickup = true;
				count++;
				
				for (int k=0 ; k < temp.size() ; k++) { 
					if (temp.get(k).getX() == oldState.agentX && temp.get(k).getY() == oldState.agentY) {
						temp.get(k).setP(ship.getP()-1);
						ship.setP(ship.getP()-1);
						index = k;
					}
				}			
		}
		
		if (canPickup) {
			actions.add("pickup");
			if(id) {
				System.out.println("old state depth before creating new state: "+ oldState.depth);
				newState = new AgentState(oldState.agentX, oldState.agentY, count, oldState.boxesRetrieved, oldState.ships, "pickup", actions, depthClone(oldState.depth)+1 , deaths);
				System.out.println("old state depth after creating new state: "+ oldState.depth);
				System.out.println("new state depth: "+ newState.depth);
			}
			else {
				newState = new AgentState(oldState.agentX, oldState.agentY, count, oldState.boxesRetrieved, oldState.ships, "pickup", actions, deaths);

			}
			
			for (int k=0 ; k < newState.ships.size() ; k++) {
				
				if (newState.ships.get(k).getP() > 0) {
					remainingPassengers--;
					deaths ++;
//					totalDeaths++;
					newState.ships.get(k).damage();
				}
				
			}
			newState.deadPassengers = deaths;

		}
		
		
		AgentState retState = null;
		
		if (newState.ships.get(index).getP() <= 0) {
			if (!id) {
				newState.ships.get(index).wreck = true;
				retState = retrieve(newState, newState.ships.get(index),false);	
			}
			
			else { //ID
				newState.ships.get(index).wreck = true;
				//retrieve(newState, newState.ships.get(index),true);
				
				if (newState.ships.get(index).wreck && newState.ships.get(index).getDamage() < 100 && newState.ships.get(index).boxState == BoxState.Available) {
					yallaRetrieve = true;
				}
				
			}
			
		}
		
		if (retState != null) {
			return retState;
		}
		
		return newState;
		
	}
	
	public static AgentState retrieve(AgentState oldState, Ship ship, boolean id) throws CloneNotSupportedException{
		
		int deaths = oldState.deadPassengers;
		AgentState newState = null;
		
		Ship sh = shipClone(ship);
		
		ArrayList<Ship> temp = new ArrayList<Ship>();
		ArrayList<String> actions = actionsClone(oldState.actions);
		
		for (int i=0; i < oldState.ships.size(); i++) {
			temp.add(shipClone((Ship)oldState.ships.get(i)));			
		}
		
		//ship.getDamage() < 100 && ship.getP() == 0
		
//		System.out.println("DAKHAL EL RETRIEVE METHOD");
		
		if (sh.wreck && sh.getDamage() < 100 && sh.boxState == BoxState.Available) {
			actions.add("retrieve");
			if(id) {
				System.out.println("old state depth before creating new state: "+ oldState.depth);
				newState = new AgentState(oldState.agentX, oldState.agentY, oldState.passengersOnBoard, boxesRetrievedClone(oldState.boxesRetrieved), oldState.ships, "retrieve", actions, depthClone(oldState.depth)+1, deaths);
				System.out.println("old state depth after creating new state: "+ oldState.depth);
				System.out.println("new state depth: "+ newState.depth);
			}
			else {
				newState = new AgentState(oldState.agentX, oldState.agentY, oldState.passengersOnBoard, boxesRetrievedClone(oldState.boxesRetrieved), oldState.ships, "retrieve", actions, deaths);
			}
			
			newState.boxesRetrieved++;
			//blackBoxesCollected++;
			
			for (int k=0 ; k < newState.ships.size() ; k++) {
				if (newState.ships.get(k).getX() == oldState.agentX && newState.ships.get(k).getY() == oldState.agentY) {
					newState.ships.get(k).boxState = BoxState.Collected;
					//blackBoxesCollected++;
					
				}
			}
			
			for (int k=0 ; k < newState.ships.size() ; k++) {
				
				if (newState.ships.get(k).getP() > 0) {
					remainingPassengers--;
					deaths ++;
					newState.ships.get(k).damage();
				}
				
			}
			newState.deadPassengers = deaths;
		}
		
		
		return newState;
	}
	
	public static AgentState drop(AgentState oldState, boolean id) throws CloneNotSupportedException{
		
		int deaths = oldState.deadPassengers;
		
		AgentState newState = null;
		ArrayList<Ship> temp = new ArrayList<Ship>();
		ArrayList<String> actions = actionsClone(oldState.actions);
		
		for (int i=0; i < oldState.ships.size(); i++) {
			temp.add(shipClone((Ship)oldState.ships.get(i)));
			
		}
		
		if(gr[oldState.agentX][oldState.agentY].station && oldState.passengersOnBoard > 0) {			
			actions.add("drop");
			if(id) {
				System.out.println("old state depth before creating new state: "+ oldState.depth);
				newState = new AgentState(oldState.agentX, oldState.agentY, 0, oldState.boxesRetrieved, oldState.ships, "drop", actions, depthClone(oldState.depth)+1 , deaths);
				System.out.println("old state depth after creating new state: "+ oldState.depth);
				System.out.println("new state depth: "+ newState.depth);	
			}
			else {
				newState = new AgentState(oldState.agentX, oldState.agentY, 0, oldState.boxesRetrieved, oldState.ships, "drop", actions, deaths);

			}
			
			for (int k=0 ; k < newState.ships.size() ; k++) {
				
				if (newState.ships.get(k).getP() > 0) {
					remainingPassengers--;
					deaths ++;
					newState.ships.get(k).damage();
				}
							}
			newState.deadPassengers = deaths;
		}
				
		return newState;
	}
	
	public static String id() throws CloneNotSupportedException {

		String result = "";

		for (int depth = 0 ;; depth++) {
		 	Stack<AgentState> dfsStack = new Stack<AgentState>();
			
			ArrayList<String> initialActions = new ArrayList<String>();
			
			AgentState agentState = new AgentState(agent.getX(),agent.getY(),0,0,ships,"",initialActions,0);
			dfsStack.push(agentState);

			System.out.println("depth: "+depth);
			while (!dfsStack.isEmpty())  {
				AgentState ag = dfsStack.pop();
				
				nodesExpanded++; //---------------------------------------------------
				
				System.out.println("current depth: "+ ag.depth);

				if(IsGoal(ag)) {
					for (int i=0 ; i< ag.actions.size() ; i++) {
						result += ag.actions.get(i) + ",";
					}
					result = result.substring(0, result.length()-1);
					totalDeaths = ag.deadPassengers;
					return result;
				}
				
				if (ag.depth < depth) {
				
				if (!contains(visitedStates, ag.stateToString())) {
					visitedStates.add(ag.stateToString());			

					Ship sh = null;
					for (int k=0 ; k < ag.ships.size() ; k++) {				
						if (ag.ships.get(k).getX() == ag.agentX && ag.ships.get(k).getY() == ag.agentY) {
						sh = ag.ships.get(k);
						}
					}
				
				if (sh != null) {
					if (sh.boxState == BoxState.Available && sh.damage < 100) {
						if (sh.getP() > 0 && ag.passengersOnBoard < agent.getC()){
							AgentState pickup = pickup(ag,sh,true);								
							if (pickup != null && pickup.depth <= depth) {
								dfsStack.push(pickup);
								for (int i=0 ; i< pickup.actions.size() ; i++) {
									System.out.println(pickup.actions.get(i));
								}
								System.out.println("-----------------------------------------------");
							}
						}
						
						if (yallaRetrieve) {
							AgentState retrieve = retrieve(ag,sh,true);
							if (retrieve != null && retrieve.depth <= depth) {
								
								System.out.println("AAAAAAAAAAA");
								System.out.println(retrieve.boxesRetrieved);

								blackBoxesCollected = retrieve.boxesRetrieved;

								dfsStack.push(retrieve);
								for (int i=0 ; i< retrieve.actions.size() ; i++) {
									System.out.println(retrieve.actions.get(i));
								}
								System.out.println("-----------------------------------------------");
								yallaRetrieve = false;
							}
						}
						
//						else if (sh.getP() == 0 && sh.boxState == BoxState.Available && sh.damage < 100) {
//							AgentState retrieve = retrieve(ag,sh,true);
//							if (retrieve != null && retrieve.depth <= depth) {
//								dfsStack.push(retrieve);
//								for (int i=0 ; i< retrieve.actions.size() ; i++) {
//									System.out.println(retrieve.actions.get(i));
//								}
//								System.out.println("-----------------------------------------------");
//							}
//						}
							
					}	
					
				}
				
				AgentState drop = drop(ag,true);
				if (drop != null && drop.depth <= depth) {
					dfsStack.push(drop);
					for (int i=0 ; i< drop.actions.size() ; i++) {
						System.out.println(drop.actions.get(i));
					}
					System.out.println("-----------------------------------------------");
				}

				AgentState up = moveUp(ag,true);
				if (up != null && up.depth <= depth) {
					dfsStack.push(up);
					for (int i=0 ; i< up.actions.size() ; i++) {
						System.out.println(up.actions.get(i));
					}
					System.out.println("-----------------------------------------------");
				}
				
				AgentState down = moveDown(ag,true);
				if (down != null && down.depth <= depth) {
					dfsStack.push(down);
					for (int i=0 ; i< down.actions.size() ; i++) {
						System.out.println(down.actions.get(i));
					}
					System.out.println("-----------------------------------------------");
				}
				
				AgentState right = moveRight(ag,true);
				if (right != null && right.depth <= depth) {
					dfsStack.push(right);
					for (int i=0 ; i< right.actions.size() ; i++) {
						System.out.println(right.actions.get(i));
					}
					System.out.println("-----------------------------------------------");
				}
				
				AgentState left = moveLeft(ag,true);
				if (left != null && left.depth <= depth) {
					dfsStack.push(left);
					for (int i=0 ; i< left.actions.size() ; i++) {
						System.out.println(left.actions.get(i));
					}
					System.out.println("-----------------------------------------------");
				}
				
				}
			  }
			}
		}
		
	}
	
	@SuppressWarnings("static-access")
	public static void isCollected() {
		for(int i = 0 ; i < ships.size() ; i++) {
			if(ships.get(i).boxState == ships.get(i).boxState.Collected) {
				blackBoxesCollected++;
			}
		}
	}
	
	public static String dfs() throws CloneNotSupportedException {
        Stack<AgentState> dfsStack = new Stack<AgentState>();
		String result = "";
		
		ArrayList<String> initialActions = new ArrayList<String>();
		
		AgentState agentState = new AgentState(agent.getX(),agent.getY(),0,0,ships,"",initialActions,0);
		dfsStack.push(agentState);
		
		while (dfsStack.size() > 0)  {
			AgentState ag = dfsStack.pop();
			
			nodesExpanded++;
			
			if(IsGoal(ag)) {
				for (int i=0 ; i< ag.actions.size() ; i++) {
//					System.out.println(ag.actions.get(i));
					result += ag.actions.get(i) + ",";
				}
				
				totalDeaths = ag.deadPassengers;
				blackBoxesCollected = ag.boxesRetrieved;
				break;
			}
			
			if (!contains(visitedStates, ag.stateToString())) {
				visitedStates.add(ag.stateToString());			
			
			Ship sh = null;
			for (int k=0 ; k < ag.ships.size() ; k++) {				
				if (ag.ships.get(k).getX() == ag.agentX && ag.ships.get(k).getY() == ag.agentY) {
					sh = ag.ships.get(k);
				}
			}
			
			if (sh != null) {
				
				if (sh.boxState == BoxState.Available && sh.damage < 100) {
					if (sh.getP() > 0 && ag.passengersOnBoard < agent.getC()){
						AgentState pickup = pickup(ag,sh,false);
						if (pickup != null) {
							dfsStack.push(pickup);
							for (int i=0 ; i< pickup.actions.size() ; i++) {
								System.out.println(pickup.actions.get(i));
							}
							System.out.println("-----------------------------------------------");
						}
					}
					
					else if (sh.getP() == 0 && sh.boxState == BoxState.Available && sh.damage < 100) {
						AgentState retrieve = retrieve(ag,sh,false);
						if (retrieve != null) {
							dfsStack.push(retrieve);
							for (int i=0 ; i< retrieve.actions.size() ; i++) {
								System.out.println(retrieve.actions.get(i));
							}
							System.out.println("-----------------------------------------------");
						}
					}
					
					
				}
					
				
			}
			
			AgentState drop = drop(ag,false);
			if (drop != null) {
				dfsStack.push(drop);
				for (int i=0 ; i< drop.actions.size() ; i++) {
					System.out.println(drop.actions.get(i));
				}
				System.out.println("-----------------------------------------------");
			}

			AgentState up = moveUp(ag,false);
			if (up != null) {
				dfsStack.push(up);
				for (int i=0 ; i< up.actions.size() ; i++) {
					System.out.println(up.actions.get(i));
				}
				System.out.println("-----------------------------------------------");
			}
			
			AgentState down = moveDown(ag,false);
			if (down != null) {
				dfsStack.push(down);
				for (int i=0 ; i< down.actions.size() ; i++) {
					System.out.println(down.actions.get(i));
				}
				System.out.println("-----------------------------------------------");
			}
			
			AgentState right = moveRight(ag,false);
			if (right != null) {
				dfsStack.push(right);
				for (int i=0 ; i< right.actions.size() ; i++) {
					System.out.println(right.actions.get(i));
				}
				System.out.println("-----------------------------------------------");
			}
			
			AgentState left = moveLeft(ag,false);
			if (left != null) {
				dfsStack.push(left);
				for (int i=0 ; i< left.actions.size() ; i++) {
					System.out.println(left.actions.get(i));
				}
				System.out.println("-----------------------------------------------");
			}
			
		}
		 }
		
		result = result.substring(0, result.length()-1);		
		return result;
	}
	
	public static String bfs() throws CloneNotSupportedException {
		Queue<AgentState> bfsQueue = new LinkedList<>();
		String result = "";
		
		ArrayList<String> initialActions = new ArrayList<String>();
		
		AgentState agentState = new AgentState(agent.getX(),agent.getY(),0,0,ships,"",initialActions,0);
		bfsQueue.add(agentState);
		
		while (bfsQueue.size() > 0)  {
			AgentState ag = bfsQueue.remove();
			
			nodesExpanded++;

			if(IsGoal(ag)) {
				for (int i=0 ; i< ag.actions.size() ; i++) {
//					System.out.println(ag.actions.get(i));
					result += ag.actions.get(i) + ",";
				}
				
				totalDeaths = ag.deadPassengers;
				blackBoxesCollected = ag.boxesRetrieved;
				break;
			}
			
			if (!contains(visitedStates, ag.stateToString())) {
				visitedStates.add(ag.stateToString());			
			
			Ship sh = null;
			for (int k=0 ; k < ag.ships.size() ; k++) {				
				if (ag.ships.get(k).getX() == ag.agentX && ag.ships.get(k).getY() == ag.agentY) {
					sh = ag.ships.get(k);
				}
			}
			
			if (sh != null) {
				
				if (sh.boxState == BoxState.Available && sh.damage < 100) {
					if (sh.getP() > 0 && ag.passengersOnBoard < agent.getC()){
						AgentState pickup = pickup(ag,sh,false);
						if (pickup != null) {
							bfsQueue.add(pickup);
//							for (int i=0 ; i< pickup.actions.size() ; i++) {
//								System.out.println(pickup.actions.get(i));
//							}
//							System.out.println("-----------------------------------------------");
						}
					}
					
					else if (sh.getP() == 0 && sh.boxState == BoxState.Available && sh.damage < 100) {
						AgentState retrieve = retrieve(ag,sh,false);
						if (retrieve != null) {
							bfsQueue.add(retrieve);
//							for (int i=0 ; i< retrieve.actions.size() ; i++) {
//								System.out.println(retrieve.actions.get(i));
//							}
//							System.out.println("-----------------------------------------------");
						}
					}

				}		
			}
			
			AgentState drop = drop(ag,false);
			if (drop != null) {
				bfsQueue.add(drop);
//				for (int i=0 ; i< drop.actions.size() ; i++) {
//					System.out.println(drop.actions.get(i));
//				}
//				System.out.println("-----------------------------------------------");
			}

			AgentState up = moveUp(ag,false);
			if (up != null) {
				bfsQueue.add(up);
//				for (int i=0 ; i< up.actions.size() ; i++) {
//					System.out.println(up.actions.get(i));
//				}
//				System.out.println("-----------------------------------------------");
			}
			
			AgentState down = moveDown(ag,false);
			if (down != null) {
				bfsQueue.add(down);
//				for (int i=0 ; i< down.actions.size() ; i++) {
//					System.out.println(down.actions.get(i));
//				}
//				System.out.println("-----------------------------------------------");
			}
			
			AgentState right = moveRight(ag,false);
			if (right != null) {
				bfsQueue.add(right);
//				for (int i=0 ; i< right.actions.size() ; i++) {
//					System.out.println(right.actions.get(i));
//				}
//				System.out.println("-----------------------------------------------");
			}
			
			AgentState left = moveLeft(ag,false);
			if (left != null) {
				bfsQueue.add(left);
//				for (int i=0 ; i< left.actions.size() ; i++) {
//					System.out.println(left.actions.get(i));
//				}
//				System.out.println("-----------------------------------------------");
			}
			
		   }
		 }
		
		result = result.substring(0, result.length()-1);
		return result;
	}
	
	
	public static String GR1() throws CloneNotSupportedException {
		ArrayList<String> initialActions = new ArrayList<String>();
		String result = "";
		PriorityQueue<Node> queue = new PriorityQueue<Node>(1, new Comparator<Node>() {
			public int compare(Node node1, Node node2) {
				if (node1.cost < node2.cost)
					return -1;
				if (node1.cost > node2.cost)
					return 1;
				return 0;
			}
		});
		
		AgentState agentState = new AgentState(agent.getX(),agent.getY(),0,0,ships,"",initialActions, 0, ships);
		Node root = new Node(agentState, null, 0, 0);
		
		queue.add(root);
		ArrayList<String> visitedStates = new ArrayList<String>();

		while (!queue.isEmpty()) {
			Node node = queue.remove();
			AgentState ag = node.state;
			
			nodesExpanded++;
			
			if(IsGoal(ag)) {
				for (int i=0 ; i< ag.actions.size() ; i++) {
					result += ag.actions.get(i) + ",";
				}
				totalDeaths = ag.deadPassengers;
				blackBoxesCollected = ag.boxesRetrieved;
				return result.substring(0,result.length()-1);
			}
			
//			System.out.println(node.toString());
			
			String hash = ag.stateToString();
			if (!contains(visitedStates, hash) || (ag.operator.equals("retrieve"))) {
				visitedStates.add(hash);
			
			Ship sh = null;
			for (int k=0 ; k < ag.ships.size() ; k++) {				
				if (ag.ships.get(k).getX() == ag.agentX && ag.ships.get(k).getY() == ag.agentY) {
					sh = ag.ships.get(k);
				}
			}
			
			
			if (sh != null) {
				if (sh.boxState == BoxState.Available && sh.damage < 100) {
					if (sh.getP() > 0 && ag.passengersOnBoard < agent.getC()){
						AgentState pickup = pickup(ag,sh,false);
						if (pickup != null) {
							queue.add(new Node(pickup, node, pickup.safeShips.size() - 1, node.depth + 1));
						}
					}
					
					else if (sh.getP() == 0 && sh.boxState == BoxState.Available && sh.damage < 100) {
						AgentState retrieve = retrieve(ag,sh,false);
						if (retrieve != null) {
							queue.add(new Node(retrieve, node, retrieve.safeShips.size() - 1, node.depth + 1));
						}
					}

				}		
			}
			
			
			AgentState drop = drop(ag,false);
			if (drop != null) {
				queue.add(new Node(drop, node, drop.safeShips.size() - 1, node.depth + 1));
			}

			AgentState up = moveUp(ag,false);
			if (up != null) {
				queue.add(new Node(up, node, up.safeShips.size() - 1, node.depth + 1));
			}
			
			AgentState down = moveDown(ag,false);
			if (down != null) {
				queue.add(new Node(down, node, down.safeShips.size() - 1, node.depth + 1));
			}
			
			AgentState right = moveRight(ag,false);
			if (right != null) {
				queue.add(new Node(right, node, right.safeShips.size() - 1, node.depth + 1));
			}
			
			AgentState left = moveLeft(ag,false);
			if (left != null) {
				queue.add(new Node(left, node, left.safeShips.size() - 1, node.depth + 1));
			}
			
			}
			
			ArrayList<Ship> safeShips = new ArrayList<Ship>();
			ArrayList<Ship> wreckedShips = new ArrayList<Ship>();;

			for(int i = 0 ; i < ag.safeShips.size(); i++) {
				safeShips.add(shipClone(ag.safeShips.get(i)));
			}
			
			if (ag.wreckedShips != null) {
				for(int i = 0 ; i < ag.wreckedShips.size(); i++) {
					wreckedShips.add(shipClone(ag.wreckedShips.get(i)));
				}
			}

		if (node.parentNode != null) {
				ArrayList<Ship> newWrecked = new ArrayList<Ship>();
				for (int i = 0; i < safeShips.size(); i++) {
					Ship ship = safeShips.get(i);
					if(ship.getP() > 0)
					{
						remainingPassengers -= 1;
						ship.damage();
//						totalDeaths++;
					}
					
					if(ship.wreck == true)
					{
						newWrecked.add(ship);
					}
					
				}				

				safeShips.removeAll(newWrecked);
				wreckedShips.addAll(newWrecked);
		}		

		}

		return null;

	}
	
	
	public static String GR2() throws CloneNotSupportedException {
		ArrayList<String> initialActions = new ArrayList<String>();
		String result = "";
		int cost = 0;
		PriorityQueue<Node> queue = new PriorityQueue<Node>(1, new Comparator<Node>() {
			public int compare(Node node1, Node node2) {
				if (node1.cost < node2.cost)
					return -1;
				if (node1.cost > node2.cost)
					return 1;
				return 0;
			}
		});
		
		AgentState agentState = new AgentState(agent.getX(), agent.getY(), 0, 0, ships,"",initialActions, 0, ships);
		Node root = new Node(agentState, null, 0, 0);
		
		queue.add(root);
		ArrayList<String> visitedStates = new ArrayList<String>();

		while (!queue.isEmpty()) {
			Node node = queue.remove();
			AgentState ag = node.state;
			
			nodesExpanded++;
			
			if(IsGoal(ag)) {
				for (int i=0 ; i< ag.actions.size() ; i++) {
					result += ag.actions.get(i) + ",";
				}
				totalDeaths = ag.deadPassengers;
				blackBoxesCollected = ag.boxesRetrieved;
				return result.substring(0,result.length()-1);
			}
			
//			System.out.println(node.toString());
			
			ArrayList<Ship> safeShips = new ArrayList<Ship>();
			ArrayList<Ship> wreckedShips = new ArrayList<Ship>();
			
			if (node.parentNode != null) {
				ArrayList<Ship> newWrecked = new ArrayList<Ship>();
				for (int i = 0; i < safeShips.size(); i++) {
					Ship ship = safeShips.get(i);
					if(ship.getP() > 0)
					{
						remainingPassengers -= 1;
						ship.damage();
//						totalDeaths++;
					}
					
					if(ship.wreck == true)
					{
						newWrecked.add(ship);
					}
					
					cost += (int)Math.ceil((double) ship.getP() / agent.getC());
				}				

				safeShips.removeAll(newWrecked);
				wreckedShips.addAll(newWrecked);
			}
			
			String hash = ag.stateToString();
			if (!contains(visitedStates, hash) || (ag.operator.equals("retrieve"))) {
				visitedStates.add(hash);
			
			Ship sh = null;
			for (int k=0 ; k < ag.ships.size() ; k++) {				
				if (ag.ships.get(k).getX() == ag.agentX && ag.ships.get(k).getY() == ag.agentY) {
					sh = ag.ships.get(k);
				}
			}
			
			if (sh != null) {
				if (sh.boxState == BoxState.Available && sh.damage < 100) {
					if (sh.getP() > 0 && ag.passengersOnBoard < agent.getC()){
						AgentState pickup = pickup(ag,sh,false);
						if (pickup != null) {
							queue.add(new Node(pickup, node, cost, node.depth + 1));
						}
					}
					
					else if (sh.getP() == 0 && sh.boxState == BoxState.Available && sh.damage < 100) {
						AgentState retrieve = retrieve(ag,sh,false);
						if (retrieve != null) {
							queue.add(new Node(retrieve, node, cost, node.depth + 1));
						}
					}

				}		
			}
			
			AgentState drop = drop(ag,false);
			if (drop != null) {
				queue.add(new Node(drop, node, cost, node.depth + 1));
			}

			AgentState up = moveUp(ag,false);
			if (up != null) {
				queue.add(new Node(up, node, cost, node.depth + 1));
			}
			
			AgentState down = moveDown(ag,false);
			if (down != null) {
				queue.add(new Node(down, node, cost, node.depth + 1));
			}
			
			AgentState right = moveRight(ag,false);
			if (right != null) {
				queue.add(new Node(right, node, cost, node.depth + 1));
			}
			
			AgentState left = moveLeft(ag,false);
			if (left != null) {
				queue.add(new Node(left, node, cost, node.depth + 1));
			}
			
			}

			for(int i = 0 ; i < ag.safeShips.size(); i++) {
				safeShips.add(shipClone(ag.safeShips.get(i)));
			}
			
			if (ag.wreckedShips != null) {
				for(int i = 0 ; i < ag.wreckedShips.size(); i++) {
					wreckedShips.add(shipClone(ag.wreckedShips.get(i)));
				}
			}
		
		}

		return null;

	}
	
	public static String AS1() throws CloneNotSupportedException {
		ArrayList<String> initialActions = new ArrayList<String>();
		String result = "";
		PriorityQueue<Node> queue = new PriorityQueue<Node>(1, new Comparator<Node>() {
			public int compare(Node node1, Node node2) {
				if (node1.cost < node2.cost)
					return -1;
				if (node1.cost > node2.cost)
					return 1;
				return 0;
			}
		});
		
		AgentState agentState = new AgentState(agent.getX(),agent.getY(),0,0,ships,"",initialActions,0, ships);
		Node root = new Node(agentState, null, 0, 0);
		
		queue.add(root);
		ArrayList<String> visitedStates = new ArrayList<String>();

		while (!queue.isEmpty()) {
			Node node = queue.remove();
			AgentState ag = node.state;
			
			nodesExpanded++;

			if(IsGoal(ag)) {
				for (int i=0 ; i< ag.actions.size() ; i++) {
					result += ag.actions.get(i) + ",";
				}
				totalDeaths = ag.deadPassengers;
				blackBoxesCollected = ag.boxesRetrieved;
				return result.substring(0,result.length()-1);
			}
			
//			System.out.println(node.toString());
			
			String hash = ag.stateToString();
			if (!contains(visitedStates, hash) || (ag.operator.equals("retrieve"))) {
				visitedStates.add(hash);
			
			Ship sh = null;
			for (int k=0 ; k < ag.ships.size() ; k++) {				
				if (ag.ships.get(k).getX() == ag.agentX && ag.ships.get(k).getY() == ag.agentY) {
					sh = ag.ships.get(k);
				}
			}
			
			
			if (sh != null) {
				if (sh.boxState == BoxState.Available && sh.damage < 100) {
					if (sh.getP() > 0 && ag.passengersOnBoard < agent.getC()){
						AgentState pickup = pickup(ag,sh,false);
						if (pickup != null) {
							queue.add(new Node(pickup, node, pickup.safeShips.size() - 1 + node.depth + 1, node.depth + 1));
						}
					}
					
					else if (sh.getP() == 0 && sh.boxState == BoxState.Available && sh.damage < 100) {
						AgentState retrieve = retrieve(ag,sh,false);
						if (retrieve != null) {
							queue.add(new Node(retrieve, node, retrieve.safeShips.size() - 1 + node.depth + 1, node.depth + 1));
						}
					}

				}		
			}
			
			
			AgentState drop = drop(ag,false);
			if (drop != null) {
				queue.add(new Node(drop, node, drop.safeShips.size() - 1 + node.depth + 1, node.depth + 1));
			}

			AgentState up = moveUp(ag,false);
			if (up != null) {
				queue.add(new Node(up, node, up.safeShips.size() - 1 + node.depth + 1, node.depth + 1));
			}
			
			AgentState down = moveDown(ag,false);
			if (down != null) {
				queue.add(new Node(down, node, down.safeShips.size() - 1 + node.depth + 1, node.depth + 1));
			}
			
			AgentState right = moveRight(ag,false);
			if (right != null) {
				queue.add(new Node(right, node, right.safeShips.size() - 1 + node.depth + 1, node.depth + 1));
			}
			
			AgentState left = moveLeft(ag,false);
			if (left != null) {
				queue.add(new Node(left, node, left.safeShips.size() - 1 + node.depth + 1, node.depth + 1));
			}
			
			}
			
			ArrayList<Ship> safeShips = new ArrayList<Ship>();
			ArrayList<Ship> wreckedShips = new ArrayList<Ship>();;

			for(int i = 0 ; i < ag.safeShips.size(); i++) {
				safeShips.add(shipClone(ag.safeShips.get(i)));
			}
			
			if (ag.wreckedShips != null) {
				for(int i = 0 ; i < ag.wreckedShips.size(); i++) {
					wreckedShips.add(shipClone(ag.wreckedShips.get(i)));
				}
			}

		if (node.parentNode != null) {
				ArrayList<Ship> newWrecked = new ArrayList<Ship>();
				for (int i = 0; i < safeShips.size(); i++) {
					Ship ship = safeShips.get(i);
					if(ship.getP() > 0)
					{
						remainingPassengers -= 1;
//						totalDeaths++;
						ship.damage();
					}
					
					if(ship.wreck == true)
					{
						newWrecked.add(ship);
					}
					
				}				

				safeShips.removeAll(newWrecked);
				wreckedShips.addAll(newWrecked);
		}		

		}

		return null;

	}
	
	public static String AS2() throws CloneNotSupportedException {
		ArrayList<String> initialActions = new ArrayList<String>();
		String result = "";
		PriorityQueue<Node> queue = new PriorityQueue<Node>(1, new Comparator<Node>() {
			public int compare(Node node1, Node node2) {
				if (node1.cost < node2.cost)
					return -1;
				if (node1.cost > node2.cost)
					return 1;
				return 0;
			}
		});
		
		AgentState agentState = new AgentState(agent.getX(),agent.getY(),0,0,ships,"",initialActions,0, ships);
		Node root = new Node(agentState, null, 0, 0);
		
		queue.add(root);
		ArrayList<String> visitedStates = new ArrayList<String>();

		while (!queue.isEmpty()) {
			Node node = queue.remove();
			AgentState ag = node.state;
			int cost = 0;

			nodesExpanded++;
			
			if(IsGoal(ag)) {
				for (int i=0 ; i< ag.actions.size() ; i++) {
					result += ag.actions.get(i) + ",";
				}
				totalDeaths = ag.deadPassengers;
				blackBoxesCollected = ag.boxesRetrieved;
				return result.substring(0,result.length()-1);
			}
			
//			System.out.println(node.toString());
			
			String hash = ag.stateToString();
			if (!contains(visitedStates, hash) || (ag.operator.equals("retrieve"))) {
				visitedStates.add(hash);
			
			Ship sh = null;
			for (int k=0 ; k < ag.ships.size() ; k++) {				
				if (ag.ships.get(k).getX() == ag.agentX && ag.ships.get(k).getY() == ag.agentY) {
					sh = ag.ships.get(k);
				}
			}
			
			
			if (sh != null) {
				if (sh.boxState == BoxState.Available && sh.damage < 100) {
					if (sh.getP() > 0 && ag.passengersOnBoard < agent.getC()){
						AgentState pickup = pickup(ag,sh,false);
						if (pickup != null) {
							queue.add(new Node(pickup, node, cost + node.depth + 1, node.depth + 1));
						}
					}
					
					else if (sh.getP() == 0 && sh.boxState == BoxState.Available && sh.damage < 100) {
						AgentState retrieve = retrieve(ag,sh,false);
						if (retrieve != null) {
							queue.add(new Node(retrieve, node, cost + node.depth + 1, node.depth + 1));
						}
					}

				}		
			}
			
			AgentState drop = drop(ag,false);
			if (drop != null) {
				queue.add(new Node(drop, node, cost + node.depth + 1, node.depth + 1));
			}

			AgentState up = moveUp(ag,false);
			if (up != null) {
				queue.add(new Node(up, node, cost + node.depth + 1, node.depth + 1));
			}
			
			AgentState down = moveDown(ag,false);
			if (down != null) {
				queue.add(new Node(down, node, cost + node.depth + 1, node.depth + 1));
			}
			
			AgentState right = moveRight(ag,false);
			if (right != null) {
				queue.add(new Node(right, node, cost + node.depth + 1, node.depth + 1));
			}
			
			AgentState left = moveLeft(ag,false);
			if (left != null) {
				queue.add(new Node(left, node, cost + node.depth + 1, node.depth + 1));
			}
			
			}
			
			ArrayList<Ship> safeShips = new ArrayList<Ship>();
			ArrayList<Ship> wreckedShips = new ArrayList<Ship>();;

			for(int i = 0 ; i < ag.safeShips.size(); i++) {
				safeShips.add(shipClone(ag.safeShips.get(i)));
			}
			
			if (ag.wreckedShips != null) {
				for(int i = 0 ; i < ag.wreckedShips.size(); i++) {
					wreckedShips.add(shipClone(ag.wreckedShips.get(i)));
				}
			}

		if (node.parentNode != null) {
				ArrayList<Ship> newWrecked = new ArrayList<Ship>();
				for (int i = 0; i < safeShips.size(); i++) {
					Ship ship = safeShips.get(i);
					if(ship.getP() > 0)
					{
						remainingPassengers -= 1;
						ship.damage();
//						totalDeaths++;
					}
					
					if(ship.wreck == true)
					{
						newWrecked.add(ship);
					}
					
					cost += (int)Math.ceil((double) ship.getP() / agent.getC());
	
				}				

				safeShips.removeAll(newWrecked);
				wreckedShips.addAll(newWrecked);
		}		

		}

		return null;

	}
	
	
	public static boolean IsGoal(AgentState s) {
		for(int i = 0 ; i < s.ships.size() ; i++) {
			if(s.ships.get(i).p > 0 || s.passengersOnBoard > 0 || s.ships.get(i).boxState.equals(BoxState.Available) ) {
				return false;
			}		
		}
//		System.out.println(s.passengersOnBoard);
		return true;
	}
	
	
//	public static String solve(String grid, String strategy, boolean visualize) {
//		String res = "";
//		
//		initializeGrid(grid);
//		
//		switch(strategy) {
//		case "BF" : try {
//				res = bfs();
//			} catch (CloneNotSupportedException e) {
//				e.printStackTrace();
//			} break;
//		case "DF" : try {
//				res = dfs();
//			} catch (CloneNotSupportedException e) {
//				e.printStackTrace();
//			} break;
//		
//		case "ID" :
//			try {
//				res = id();
//			} catch (CloneNotSupportedException e) {
//				e.printStackTrace();
//			} break;
//		case "GR1" : try {
//			res = GR1();
//		} catch (CloneNotSupportedException e) {
//			e.printStackTrace();
//		} break;
//		case "GR2" : try {
//			res = GR2();
//		} catch (CloneNotSupportedException e) {
//			e.printStackTrace();
//		} break;
//		case "AS1" : try {
//			res = AS1();
//		} catch (CloneNotSupportedException e) {
//			e.printStackTrace();
//		} break;
//		case "AS2" : try {
//			res = AS2();
//		} catch (CloneNotSupportedException e) {
//			e.printStackTrace();
//		} break;
//		}
//		
//		if (visualize)
//			visualize(res);
//		
//		int n= nodesExpanded;
//		nodesExpanded = 0;
//		
//		return res+";"+totalDeaths+";"+blackBoxesCollected+";"+n;
//
//	}
	
	public void totalDeaths(ArrayList<Ship> ships) {
		for (int i = 0 ; i > ships.size() ; i++) {
			deaths += ships.get(i).deceased;	
		}
	}
		
	public static Ship shipClone(Ship sh) {
		Ship newShip = new Ship();
		newShip.p = sh.p;
		newShip.boxState = sh.boxState;
		newShip.wreck = sh.wreck;
		newShip.x = sh.x;
		newShip.y = sh.y;
		newShip.p = sh.p;
		newShip.deceased = sh.deceased;
		newShip.damage = sh.damage;
		
		return newShip;
	}
	
	public static ArrayList<String> actionsClone(ArrayList<String> actions) {

		ArrayList<String> a = new ArrayList<String>();
		
		for (int i = 0 ; i < actions.size() ; i++) {
			a.add(actions.get(i));
		}
		
		return a;
	}
	
	
	public static int passengersOnBoardClone(int x) {
		int newPass = x;
		return newPass;
	}
	
	public static int boxesRetrievedClone(int x) {
		int newBoxes = x;
		return newBoxes;
	}
	
	public static int xClone(int x) {
		int newX = x;
		return newX;
	}
	
	public static int yClone(int y) {
		int newY = y;
		return newY;
	}
	
	public static int depthClone(int d) {
		int newD = d;
		return newD;
	}
	
	public static boolean contains(ArrayList<String> arr, String str) {
		for (int i = 0; i < arr.size(); i++) { //---------------------------------
			if (str.equals(arr.get(i)))
				return true;
		}
		return false;
	}
	
	public static void initializeGrid(String grid) {
		String[] gridArray = grid.split(";");
		String[] gridDimensions = gridArray[0].split(",");
				
		m = Integer.parseInt(gridDimensions[0]);
		n = Integer.parseInt(gridDimensions[1]);
		c = Integer.parseInt(gridArray[1]);
		
		gr = new Cell[n][m];
		
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				gr[i][j] = new Cell(n,m);
				gr[i][j].setX(i);
				gr[i][j].setY(j);
			}

		}
//		CoastGuard cg = new CoastGuard();
		
		String[] initialPosition = gridArray[2].split(",");

		agent = new Agent(c);
		agent.setX(Integer.parseInt(initialPosition[0]));
		agent.setY(Integer.parseInt(initialPosition[1]));
		
		gr[Integer.parseInt(initialPosition[0])][Integer.parseInt(initialPosition[1])].setEmpty(false); //----------------
		gr[Integer.parseInt(initialPosition[0])][Integer.parseInt(initialPosition[1])].setX(agent.getX());
		gr[Integer.parseInt(initialPosition[0])][Integer.parseInt(initialPosition[1])].setY(agent.getY());
		
		String[] stationsArr = gridArray[3].split(",");
		for (int i = 0; i <= stationsArr.length / 2; i += 2) {
			int stationX = Integer.parseInt(stationsArr[i]);
			int stationY = Integer.parseInt(stationsArr[i + 1]);
			
			System.out.println(stationX);
			System.out.println(stationY);
			
			gr[stationX][stationY].setEmpty(false); //------------------
			gr[stationX][stationY].setStation(true);
			gr[stationX][stationY].setX(stationX);
			gr[stationX][stationY].setY(stationY);
		}
		
		String[] shipsArr = gridArray[4].split(",");
		
//		ArrayList<Ship> ships = new ArrayList<Ship>();
		
		for (int i = 2; i < shipsArr.length; i += 3) {
			int shipX = Integer.parseInt(shipsArr[i - 2]);
			int shipY = Integer.parseInt(shipsArr[i - 1]);
			int p = Integer.parseInt(shipsArr[i]);
			
			remainingPassengers += p;
			
			gr[shipX][shipY].setEmpty(false);
			gr[shipX][shipY].setShip(true);
			gr[shipX][shipY].setX(shipX);
			gr[shipX][shipY].setY(shipY);
			
			ships.add(new Ship(shipX, shipY, p));
		}		
	}
	
	public static void main(String[] args) {
// 		String grid0 = "5,6;50;0,1;0,4,3,3;1,1,90;";

	}
}
