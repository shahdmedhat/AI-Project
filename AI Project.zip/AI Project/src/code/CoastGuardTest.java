//package code;
//
//import java.util.ArrayList;
//import java.util.LinkedList;
//import java.util.Queue;
//
//public class CoastGuardTest {
//	String grid;
//	int[] cell;
//	int remainingPass;
//	int maxNoOfPass;
//	int noOfShips;
//	static Object[][] gridArr;
//	static ArrayList<String> visitedStates = new ArrayList<String>();
//	static ArrayList<Station> stations;
//	int remainingAlivePass;
//	int[] goalTest = new int[3];
//	int[]  initialState= new int[2];
//	
//	public CoastGuardTest(int x, int y, int remainingPass, int maxNoOfPass, int[] goalTest, int remainingAlivePass) {
//		this.cell = new int[2];
//		this.cell[0] = x;
//		this.cell[1] = y;
//		this.remainingPass = remainingPass;
//		this.maxNoOfPass = maxNoOfPass;
//		this.goalTest = clone(goalTest);
//		this.remainingAlivePass = remainingAlivePass;
//	}
//
//	public CoastGuardTest() {
//		this.cell = new int[2];
//	}
//	
//	
//	public static Node InitializeCoastGuard(CoastGuardTest coastGuard, String grid) {
//		String[] gridArray = grid.split(";");
//		String[] GS = gridArray[0].split(",");
//
//		gridArr = new Object[Integer.parseInt(GS[1])][Integer.parseInt(GS[0])];
//
//		coastGuard.maxNoOfPass = Integer.parseInt(gridArray[1]);
//		coastGuard.remainingPass = Integer.parseInt(gridArray[1]);
//		coastGuard.goalTest[0] = 0; // No of passengers on board
//
//		// Coast Guard's Initial State
//		coastGuard.initialState = new int[2];
//		String[] GuardCell = gridArray[2].split(",");
//		coastGuard.cell[0] = Integer.parseInt(GuardCell[0]);
//		coastGuard.cell[1] = Integer.parseInt(GuardCell[1]);
//		coastGuard.initialState[0] = Integer.parseInt(GuardCell[0]);
//		coastGuard.initialState[1] = Integer.parseInt(GuardCell[1]);
//
//		String[] st = gridArray[3].split(",");
//		stations = new ArrayList<Station>();
//		for (int i = 0; i <= st.length / 2; i += 2) {
//			int x = Integer.parseInt(st[i]);
//			int y = Integer.parseInt(st[i + 1]);
//			Station s = new Station(x, y);
//			stations.add(s);
//
//			gridArr[x][y] = s;
//		}
//
//		int sumOfPass = 0;
//		String[] sh = gridArray[4].split(",");
//		ArrayList<Ship> ships = new ArrayList<Ship>();
//		for (int i = 2; i < sh.length; i += 3) {
//			int x = Integer.parseInt(sh[i - 2]);
//			int y = Integer.parseInt(sh[i - 1]);
//			int maxP = Integer.parseInt(sh[i]);
//			sumOfPass += maxP;
//			ships.add(new Ship(x, y, maxP));
//		}
//
//		coastGuard.remainingAlivePass = sumOfPass;
//		coastGuard.goalTest[1] = sumOfPass;
//		coastGuard.goalTest[2] = ships.size();
//		coastGuard.noOfShips = ships.size();
//
//		AgentState currentState = new AgentState(coastGuard, ships);
//
//		Node initialNode = new Node(currentState, 0, null, null, 0);
//
//		return initialNode;
//	}
//	
//	public static int[] clone(int[] arr) {
//		int[] clone = new int[arr.length];
//
//		for (int i = 0; i < arr.length; i++) {
//			clone[i] = arr[i];
//		}
//
//		return clone;
//	}
//	
//	public static ArrayList<Ship> clone(ArrayList<Ship> arr) {
//		ArrayList<Ship> clone = new ArrayList<Ship>();
//
//		for (int i = 0; i < arr.size(); i++) {
//			Ship ship = arr.get(i);
//			clone.add(clone(ship));
//		}
//
//		return clone;
//	}
//	
//
//	public static Ship clone(Ship ship) {
//		return new Ship(ship.getX(), ship.getY(), ship.remainingPassengers, ship.blackBoxTimeRemaining,
//				ship.blackBoxRetrieved);
//	}
//	
//	public static boolean contains(ArrayList<String> arr, String str) {
//		for (int i = 0; i < arr.size(); i++) { //---------------------------------
//			if (str.equals(arr.get(i)))
//				return true;
//		}
//		return false;
//	}
//	
////	public static AgentState pickup(AgentState oldState, Ship ship, boolean id) throws CloneNotSupportedException{
////		int deaths = oldState.deadPassengers;
////		
////		AgentState newState = null;
////		boolean canPickup = false;
////		ArrayList<Ship> temp = new ArrayList<Ship>();
////
////		int index = 0;
////		int d = 0;
////		
////		ArrayList<String> actions = actionsClone(oldState.actions);
////		
////		int count = passengersOnBoardClone(oldState.passengersOnBoard);
////		
////		for (int i=0; i < oldState.ships.size(); i++) {
////			temp.add(shipClone((Ship)oldState.ships.get(i)));	
////		}
////
////		while (count <= agent.getC() && ship.getP() > 0) {
////				canPickup = true;
////				count++;
////				
////				for (int k=0 ; k < temp.size() ; k++) { 
////					if (temp.get(k).getX() == oldState.agentX && temp.get(k).getY() == oldState.agentY) {
////						temp.get(k).setP(ship.getP()-1);
////						ship.setP(ship.getP()-1);
////						index = k;
////					}
////				}			
////		}
////		
////		if (canPickup) {
////			actions.add("pickup");
////			if(id) {
////				System.out.println("old state depth before creating new state: "+ oldState.depth);
////				newState = new AgentState(oldState.agentX, oldState.agentY, count, oldState.boxesRetrieved, oldState.ships, "pickup", actions, depthClone(oldState.depth)+1 , deaths);
////				System.out.println("old state depth after creating new state: "+ oldState.depth);
////				System.out.println("new state depth: "+ newState.depth);
////			}
////			else {
////				newState = new AgentState(oldState.agentX, oldState.agentY, count, oldState.boxesRetrieved, oldState.ships, "pickup", actions, deaths);
////
////			}
////			
////			for (int k=0 ; k < newState.ships.size() ; k++) {
////				
////				if (newState.ships.get(k).getP() > 0) {
////					remainingPassengers--;
////					deaths ++;
//////					totalDeaths++;
////					newState.ships.get(k).damage();
////				}
////				
////			}
////			newState.deadPassengers = deaths;
////
////		}
////		
////		
////		AgentState retState = null;
////		
////		if (newState.ships.get(index).getP() <= 0) {
////			if (!id) {
////				newState.ships.get(index).wreck = true;
////				retState = retrieve(newState, newState.ships.get(index),false);	
////			}
////			
////			else { //ID
////				newState.ships.get(index).wreck = true;
////				//retrieve(newState, newState.ships.get(index),true);
////				
////				if (newState.ships.get(index).wreck && newState.ships.get(index).getDamage() < 100 && newState.ships.get(index).boxState == BoxState.Available) {
////					yallaRetrieve = true;
////				}
////				
////			}
////			
////		}
////		
////		if (retState != null) {
////			return retState;
////		}
////		
////		return newState;
////		
////	}
//	
//	public static int pickup(AgentState state, CoastGuardTest cg, int[] cell) {
//
//		int index = getShip(state.safeShips, cell);
//		int savedPass = 0;
//		if (index != -1) {
//			Ship ship = state.safeShips.get(index);
//			if (ship.remainingPassengers > 0 && ship.remainingPassengers <= cg.remainingPass) {
//				savedPass += ship.remainingPassengers;
//				cg.goalTest[0] += ship.remainingPassengers;
//				ship.remainingPassengers = 0;
//			} else if (ship.remainingPassengers > cg.remainingPass) {
//				savedPass += cg.remainingPass;
//				cg.goalTest[0] += cg.remainingPass;
//				ship.remainingPassengers -= cg.remainingPass;
//			}
//		}
//
//		return savedPass;
//
//	}
//	
//	
//	public static Node bfs(String grid) {
//		CoastGuardTest coastGuard = new CoastGuardTest();
//		Queue<Node> queue = new LinkedList<Node>();
//		queue.add(InitializeCoastGuard(coastGuard, grid));
//		visitedStates = new ArrayList<String>();
//
//		while (!queue.isEmpty()) {
//			Node node = queue.remove();
//			AgentState state = node.state;
//			CoastGuardTest cg = state.coastGuard;
//			int[] currCell = cg.cell;
//			int savedPass = state.safePassengers;
//			int remainingPass = cg.remainingPass;
//			int deadPass = state.deadPassengers;
//			int blackBoxRetrieved = state.boxesRetrieved;
//			int remainingAlivePass = cg.remainingAlivePass;
//
//			boolean st = false;
//
//			if (gridArr[currCell[0]][currCell[1]] instanceof Station)
//				st = true;
//
//			if (node.operator != null) {
//				if (node.operator.equals("pickup")) {
//					int x = pickup(state, cg, currCell);
//					savedPass += x;
//					remainingPass -= x;
//					remainingAlivePass -= x;
//				}
//				if (node.operator.equals("drop")) {
//					cg.goalTest[0] = 0;
//					remainingPass = cg.maxNoOfPass;
//				}
//				if (node.operator.equals("retrieve")) {
//					int index = getShip(state.wreckedShips, currCell);
//					if (index != -1) {
//						Ship ship = state.wreckedShips.get(index);
//						ship.blackBoxRetrieved = true;
//						cg.goalTest[2]--;
//						state.boxesRetrieved += 1;
//					}
//					blackBoxRetrieved += 1;
//				}
//			}
//
//			Ship s = null;
//
//			// Handling the loss of a passenger every step
//			ArrayList<Ship> safeShips = clone(state.safeShips);
//			ArrayList<Ship> wreckedShips = clone(state.wreckedShips);
//
//			if (node.parentNode != null) {
//				
//				ArrayList<Ship> newWrecked = new ArrayList<Ship>();
//				for (int i = 0; i < safeShips.size(); i++) {
//					Ship ship = safeShips.get(i);
//					
//					if(ship.remainingPassengers > 0)
//					{
//						ship.remainingPassengers -= 1;
//						deadPass += 1;
//						remainingAlivePass -= 1;
//					}
//					
//					if(ship.remainingPassengers == 0)
//					{
//						ship.blackBoxTimeRemaining-=1;
//						newWrecked.add(ship);
//					}
//
//					if (ship.getX() == currCell[0] && ship.getY() == currCell[1]) {
//						s = ship;
//					}
//
//				}
//
//				safeShips.removeAll(newWrecked);
//
//				for (int i = 0; i < wreckedShips.size(); i++) {
//					Ship ship = wreckedShips.get(i);
//
//					if (!ship.blackBoxRetrieved && ship.blackBoxTimeRemaining == 1) {
//						cg.goalTest[2]--;
//						ship.blackBoxTimeRemaining -= 1;
//					}
//
//					if (!ship.blackBoxRetrieved && ship.blackBoxTimeRemaining > 0)
//						ship.blackBoxTimeRemaining -= 1;
//
//					if (!ship.blackBoxRetrieved && ship.blackBoxTimeRemaining > 0 && ship.getX() == currCell[0]
//							&& ship.getY() == currCell[1])
//						s = ship;
//				}
//
//				wreckedShips.addAll(newWrecked);
//
//			}
//
//			// Check if we reached the goal test
//			if (cg.goalTest[0] == 0 && cg.goalTest[2] == 0)
//				return node;
//
//			String hash = state.stateToString();
//
//			// Adding nodes to the queue
//			if (!contains(visitedStates, hash)) {
//				visitedStates.add(hash);
//
//				CoastGuardTest newCG = new CoastGuardTest(currCell[0], currCell[1], remainingPass, cg.maxNoOfPass, cg.goalTest,
//						remainingAlivePass);
//				AgentState newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved,savedPass);
//
//				if (s != null && !s.blackBoxRetrieved && s.blackBoxTimeRemaining > 0) { // current Node is a ship
//					if (s.remainingPassengers > 0 && remainingPass > 0) {
//						queue.add(new Node(newState, node.depth + 1, node, "pickup", node.cost + 1));
//					} else if (s.remainingPassengers == 0 && !s.blackBoxRetrieved && s.blackBoxTimeRemaining > 0) {
//						queue.add(new Node(newState, node.depth + 1, node, "retrieve", node.cost + 1));
//					}
//
//				} else if (st == true && remainingPass < cg.maxNoOfPass) {
//					queue.add(new Node(newState, node.depth + 1, node, "drop",node.cost + 1));
//				}
//
//				else {
//					if (currCell[0] > 0) {
//						newCG = new CoastGuardTest(currCell[0] - 1, currCell[1], remainingPass, cg.maxNoOfPass, cg.goalTest,
//								remainingAlivePass);
//						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved,savedPass);
//						queue.add(new Node(newState, node.depth + 1, node, "up", node.cost + 1));
//					}
//
//					if (currCell[0] < (gridArr.length - 1)) {
//						newCG = new CoastGuardTest(currCell[0] + 1, currCell[1], remainingPass, cg.maxNoOfPass, cg.goalTest,
//								remainingAlivePass);
//						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved,savedPass);
//						queue.add(new Node(newState, node.depth + 1, node, "down",node.cost + 1));
//					}
//
//					if (currCell[1] > 0) {
//						newCG = new CoastGuardTest(currCell[0], currCell[1] - 1, remainingPass, cg.maxNoOfPass, cg.goalTest,
//								remainingAlivePass);
//						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
//						queue.add(new Node(newState, node.depth + 1, node, "left", node.cost + 1));
//					}
//
//					if (currCell[1] < (gridArr[0].length - 1)) {
//						newCG = new CoastGuardTest(currCell[0], currCell[1] + 1, remainingPass, cg.maxNoOfPass, cg.goalTest,
//								remainingAlivePass);
//						newState = new AgentState(newCG, safeShips, wreckedShips, deadPass, blackBoxRetrieved, savedPass);
//						queue.add(new Node(newState, node.depth + 1, node, "right", node.cost + 1));
//					}
//				}
//
//			}
//
//		}
//
//		return null;
//	}
//
//	public static String getNodeParents(Node n) {
//		if (n == null)
//			return "No Solution";
//		String output = "";
//		int num = 0;
//		AgentState state = n.state;
//		int deadPass = state.deadPassengers;
//		int blackBoxesRetrieved = state.boxesRetrieved;
//		while (n != null && n.parentNode != null) {
//			output = n.operator + "," + output;
//			n = n.parentNode;
//			num++;
//
//		}
//		if (output.length() > 0)
//			return output.substring(0, output.length() - 1) + ";" + deadPass + ";" + blackBoxesRetrieved + ";" + num;
//		return "No Solution";
//	}
//	
//	public static int getShip(ArrayList<Ship> ships, int[] cell) {
//
//		for (int i = 0; i < ships.size(); i++) {
//			if (ships.get(i).getX()== cell[0] && ships.get(i).getY() == cell[1])
//				return i;
//		}
//
//		return -1;
//	}
//	
//	
//	public static String solve(String grid, String strategy, boolean visualize) {
//		Node res = null;		
//		switch(strategy) {
//		case "BF" : res = bfs(grid); break;
////		case "DF" : try {
////				res = dfs();
////			} catch (CloneNotSupportedException e) {
////				e.printStackTrace();
////			} break;
////		
////		case "ID" :
////			try {
////				res = id();
////			} catch (CloneNotSupportedException e) {
////				e.printStackTrace();
////			} break;
////		case "GR1" : try {
////			res = GR1();
////		} catch (CloneNotSupportedException e) {
////			e.printStackTrace();
////		} break;
////		case "GR2" : try {
////			res = GR2();
////		} catch (CloneNotSupportedException e) {
////			e.printStackTrace();
////		} break;
////		case "AS1" : try {
////			res = AS1();
////		} catch (CloneNotSupportedException e) {
////			e.printStackTrace();
////		} break;
////		case "AS2" : try {
////			res = AS2();
////		} catch (CloneNotSupportedException e) {
////			e.printStackTrace();
////		} break;
//		}
//	
//		return getNodeParents(res);
//	}
//	
//}
