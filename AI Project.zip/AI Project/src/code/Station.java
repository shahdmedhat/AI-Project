package code;

public class Station {
	
	int[] cell ;
	
	public Station(int x ,int y)
	{
		cell = new int[2];
		
		cell[0] = x;
		cell[1] = y;
	}
	
}
