package code;

public class Ship implements Cloneable {
	
	BoxState boxState;
	boolean wreck;
	int x;
	int y;
	int p;
	
	int deceased;
	int damage;
	
	int remainingPassengers;
	int blackBoxTimeRemaining;
	boolean blackBoxRetrieved ;

	public final int compareTo(BoxState o) {
		return boxState.compareTo(o);
	}

//	public final boolean equals(Object other) {
//		return boxState.equals(other);
//	}

	public final String name() {
		return boxState.name();
	}

	public String toString() {
		return boxState.toString();
	}

	public Ship() {
		//generating a random number of passengers where 0 < p <= 100
		//p = (int) Math.floor(Math.random()*(100)+1);
//		p = 6;
		wreck = false;
		boxState = BoxState.Available;
		deceased = 0;
		damage = 0;
	}
	
	public Ship(int x, int y, int p) {
		this.p = p;
		this.x = x;
		this.y = y;
		wreck = false;
		boxState = BoxState.Available;
		deceased = 0;
		damage = 0;
	}
	
	public Ship(int x, int y, int noOfPassengers , int blackBoxTimeRemaining , boolean blackBoxRetrieved)
	{
		
		this.x = x;
		this.y = y;
		
		this.remainingPassengers = noOfPassengers;
		
		this.blackBoxTimeRemaining = blackBoxTimeRemaining;
		this.blackBoxRetrieved = blackBoxRetrieved;
	}
	
	public boolean isWreck() {
		return wreck;
	}

	public void setWreck(boolean wreck) {
		this.wreck = wreck;
	}
	
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
	
	public int getP() {
		return p;
	}
	
	public void setP(int p) {
		this.p = p;
	}
	
	public void damage() {
		if(!this.wreck) {//this.p > 0
			this.p--;
			this.deceased++;
			if(this.p == 0) {			// else?
				this.wreck = true;	
				
			}
		}
		
		else { 
			//EL NAS MATET/SAVED THEREFORE INCREMENT THE TIMER
			this.damage++;
			if(this.damage >= 100) { //this.damage ==100 && this.boxState != BoxState.Destroyed && 
				this.boxState = BoxState.Destroyed;
				//REMOVE SHIP FROM ARRAYLIST
			}
		}
		
//			if(this.damage < 100  && this.wreck == true) {
//			else {
//				this.damage ++;
//
//			}
			
		}
	
	public int getDamage() {
		return damage;
	}
	
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
        return (Ship)super.clone();
    }
	
//	public Ship clone() {
//		Ship sh = new Ship();
//		
//		sh.boxState = (BoxState) this.boxState.clone();
//		boolean wreck;
//		int x;
//		int y;
//		
//		int deceased;
//		int damage;
//				
//	}
	
	
}
