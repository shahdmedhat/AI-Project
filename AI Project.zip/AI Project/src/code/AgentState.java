package code;

import java.util.ArrayList;

public class AgentState implements Cloneable {
		
	int agentX;
	int agentY;
	int depth;
	int boxesRetrieved = 0;
	int passengersOnBoard = 0;
	CoastGuard coastGuard;
	int deadPassengers;
	String operator = "";
	
	ArrayList<Ship> ships = new ArrayList<Ship>();	
	ArrayList<String> actions = new ArrayList<String>();
	
	ArrayList<Ship> safeShips = new ArrayList<Ship>();
	ArrayList<Ship> wreckedShips ;
	int safePassengers = 0;
	
	
	public AgentState(int x, int y, int p, int b, ArrayList<Ship> sh , String operator, ArrayList<String> a, int dead, ArrayList<Ship> safeShips) throws CloneNotSupportedException {
		this.agentX = x;
		this.agentY = y;
		this.passengersOnBoard = p;
		this.boxesRetrieved = b;
		this.operator = operator;
		this.actions = a;
		this.deadPassengers = dead;
		this.safeShips = safeShips;
		this.wreckedShips = new ArrayList<Ship>();

		for (int i=0; i< sh.size(); i++) {
			ships.add((Ship) sh.get(i).clone());
		}	
		
	}
	
	public AgentState(int x, int y, int p, int b, ArrayList<Ship> sh , String operator, ArrayList<String> a, int dead) throws CloneNotSupportedException {
		this.agentX = x;
		this.agentY = y;
		this.passengersOnBoard = p;
		this.boxesRetrieved = b;
		this.operator = operator;
		this.actions = a;
		this.deadPassengers = dead;

		for (int i=0; i< sh.size(); i++) {
			ships.add((Ship) sh.get(i).clone());
		}
		
	}
	
	public AgentState(int x, int y, int p, int b, ArrayList<Ship> sh , String operator, ArrayList<String> a, int d, int dead) throws CloneNotSupportedException {
		this.agentX = x;
		this.agentY = y;
		this.passengersOnBoard = p;
		this.boxesRetrieved = b;
		this.operator = operator;
		this.actions = a;
		this.depth = d;
		this.deadPassengers = dead;

		for (int i=0; i< sh.size(); i++) {
			ships.add((Ship) sh.get(i).clone());
		}
		
	}
	
	public AgentState(CoastGuard coastGuard, ArrayList<Ship> safeShips)
	{
		this.coastGuard = coastGuard;
		this.safeShips = safeShips;
		this.wreckedShips = new ArrayList<Ship>();
	}
	
	public AgentState(CoastGuard coastGuard, ArrayList<Ship> safeShips, ArrayList<Ship> wreckedShips, int deadPassengers, int boxesRetrieved , int safePassengers)
	{
		this.coastGuard = coastGuard;
		this.safeShips = safeShips;
		this.wreckedShips = wreckedShips;
		this.deadPassengers = deadPassengers;
		this.boxesRetrieved = boxesRetrieved;
		this.safePassengers = safePassengers;
	}
	
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
	
	@SuppressWarnings("static-access")
	public String stateToString() {
		//remainingPassengers
		
		CoastGuard cg = coastGuard;
		return cg.cell[0] + ","+ cg.cell[1] + "," + cg.remainingPass + "," + boxesRetrieved + "," + deadPassengers + ","+ cg.remainingAlivePass;
			}
	
}
