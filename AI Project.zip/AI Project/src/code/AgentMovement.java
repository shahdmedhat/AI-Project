package code;

public enum AgentMovement {
	Left , Right , Up , Down , None;
}
