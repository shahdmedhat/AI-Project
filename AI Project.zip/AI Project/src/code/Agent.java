package code;

public class Agent { //extends CoastGuard

	private int c;
	
	int x = -1;
	int y = -1;
	
	int pickedUp;
	int boxesRetrieved;
	AgentMovement agentMove;
//	CoastGuard coastGuard;
	
	public Agent(int c) {
		// generating a random capacity for the ship (30 <= c <= 100)
		//c = (int) Math.floor(Math.random()*(100-30+1)+30);
		//c = 10;
		
		this.c = c;
		pickedUp = 0;
		boxesRetrieved = 0;
	}
	
	
	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
	
}
