package code;
//package code;
//
//import java.util.ArrayList;
//import java.util.LinkedList;
//import java.util.Queue;
//
//public class CoastGuard {
//
//	static Agent agent;
//	static int m;
//	static int n;
//
//	int deaths = 0;
//	
//
//	static ArrayList<Ship> ships = new ArrayList<Ship>();
//	static ArrayList<Object> stations = new ArrayList<Object>();
//	
//	static Cell[][] grid;
//	
//	Queue<String> bfsQ = new LinkedList<>(); //--------------------------------------
//	
//	
//	public static String GenGrid() {
//
//		String result = "";
//		int min = 5;
//		int max = 15;
//
//
//		// m should be greater than or equal to 5
//		// n should be less than or equal to 15
//
//		m = (int) Math.floor(Math.random() * (max - min + 1) + min); // min <= m <= max
//		n = (int) Math.floor(Math.random() * (max - min + 1) + min);
//
//		grid = new Cell[m][n];
//
//		for (int i = 0; i < m; i++) {
//			for (int j = 0; j < n; j++) {
//				// Cell c = new Cell();
//				grid[i][j] = new Cell(m,n);
//				grid[i][j].setX(i);
//				grid[i][j].setY(j);
//			}
//
//		}
//
//		agent = new Agent();
//
//		// initial position of the agent
//		int cgX = (int) Math.floor(Math.random() * m);
//		int cgY = (int) Math.floor(Math.random() * n);
//
//		agent.setX(cgX);
//		agent.setY(cgY);
//
//		grid[cgX][cgY].setEmpty(false);
////		grid[cgX][cgY].setAgent(true);
//		grid[cgX][cgY].setX(cgX);
//		grid[cgX][cgY].setY(cgY);
//
//		// M,N;C;cgX,cgY;
//		result = "" + m + "," + n + ";" + agent.getC() + ";" + cgX + "," + cgY + ";";
//		result += "\n";
//
//		// 1 -> 15?
//		int numberOfStations = (int) Math.floor(Math.random() * ((m * n - 2)) + 1);
//		int countStation = 0;
//		while (countStation < numberOfStations) {
//			int stationX = (int) Math.floor(Math.random() * (m));
//			int stationY = (int) Math.floor(Math.random() * (n));
//
//			if (grid[stationX][stationY].isEmpty()) { // empty cell -> can insert station in this cell
//				grid[stationX][stationY].setEmpty(false);
//				grid[stationX][stationY].setStation(true);
//				grid[stationX][stationY].setX(stationX);
//				grid[stationX][stationY].setY(stationY);
//
//				if (countStation == numberOfStations - 1) {
//					result += stationX + "," + stationY + ";";
//				} else {
//					result += stationX + "," + stationY + ",";
//				}
//
//				countStation++;
//			}
//		}
//
//		result += "\n";
//
//		int numberOfShips = (int) Math.floor(Math.random() * ((m * n) - numberOfStations - 1) + 1);
//		int countShip = 0;
//		while (countShip < numberOfShips) {
//			int shipX = (int) Math.floor(Math.random() * (m));
//			int shipY = (int) Math.floor(Math.random() * (n));
//
//			if (grid[shipX][shipY].isEmpty()) { // empty cell -> can insert ship in this cell
//				grid[shipX][shipY].setEmpty(false);
//				grid[shipX][shipY].setShip(true);
//				grid[shipX][shipY].setX(shipX);
//				grid[shipX][shipY].setY(shipY);
//
//				Ship sh = new Ship();
//				sh.setX(shipX);
//				sh.setY(shipY);
//
//				ships.add(sh);
//
//				if (countShip == numberOfShips - 1) {
//					result += shipX + "," + shipY + ";";
//				} else {
//					result += shipX + "," + shipY + ",";
//				}
//
//				countShip++;
//			}
//		}
//
////		for (int i = 0; i < m; i++) {
////			for (int j = 0; j < n; j++) {
//////				grid[i][j].setShips(ships); //REDUNDANTTTTTTTTTTT
////				grid[i][j].possibleActions();
////			}
////
////		}
//
//
//		return result;
//	}
//
////	public static void timeStep(){
////		for(int i = 0 ; i < ships.size() ; i++) {
////			ships.get(i).damage();	
////			if(agent.retrieve(ships.get(i))== false ) {
////				ships.remove(i);
////			}
////		}
////	}
//	
//	public static AgentState moveUp(AgentState oldState) {
//		AgentState newState = null;
//		if (oldState.agentX != 0) {
//			System.out.println("up");
////			newState = new AgentState(oldState.agentX-1, oldState.agentY, oldState.passengersOnBoard, oldState.boxesRetrieved, oldState.ships, "up");
//			
//			ArrayList<String> actions = new ArrayList<String>();
//			
//			for (int j=0; j < oldState.actions.size() ; j++) {
//				actions.add(oldState.actions.get(j));
//			}
//			
//			actions.add("up");
//			
//			
//			try {
//				newState = (AgentState) oldState.clone();
//			} catch (CloneNotSupportedException e) {
//				e.printStackTrace();
//			}
//			
//          newState.agentX--;
//          newState.operator = "up";
//			
//			for (int k=0 ; k < newState.ships.size() ; k++) {
//				newState.ships.get(k).damage();
//			}
//			
//		}
//		
//		return newState;
//	}
//	
//	public static AgentState moveDown(AgentState oldState) throws CloneNotSupportedException {
//		AgentState newState = null;
//		
//		if (oldState.agentX < m-1) {
//			System.out.println("down");
//			
//			System.out.println("parent p before: "+oldState.ships.get(0).p);
//			
//			ArrayList<Ship> temp = new ArrayList<Ship>();
//			
////			for (int k=0; k < oldState.ships.size(); k++) {
////				temp.add(oldState.ships.get(k));
////			}
//
//			//newState = new AgentState(oldState.agentX+1, oldState.agentY, oldState.passengersOnBoard, oldState.boxesRetrieved, temp, "down");
//			
//			ArrayList<String> actions = new ArrayList<String>();
//			
//			for (int j=0; j < oldState.actions.size() ; j++) {
//				actions.add(oldState.actions.get(j));
//			}
//			
//			actions.add("down");
//			
////			try {
////				newState = (AgentState) oldState.clone();
////			} catch (CloneNotSupportedException e) {
////				e.printStackTrace();
////			}
////			
////			newState.agentX++;
////			newState.operator = "down";			
//			
//			for (int i=0; i < oldState.ships.size(); i++) {
//				temp.add(shipClone((Ship)oldState.ships.get(i)));
//				
//			}
//			
////			newState.ships = temp;
//			
//			newState = new AgentState(oldState.agentX, oldState.agentY+1, oldState.passengersOnBoard, oldState.boxesRetrieved, temp, "down", actions);
//			
//			for (int k=0 ; k < newState.ships.size() ; k++) {
//				newState.ships.get(k).damage();
//			}
//			
//			
//		}
//		
//		System.out.println("parent p after: "+oldState.ships.get(0).p);
//		return newState;
//	}
//	
//	public static AgentState moveRight(AgentState oldState) throws CloneNotSupportedException {
//		AgentState newState = null;
//		if (oldState.agentY < n-1) {
//			System.out.println("right");
//			
//			System.out.println("parent p before: "+oldState.ships.get(0).p);
//
//			ArrayList<Ship> temp = new ArrayList<Ship>();
//			
//			for (int k=0; k < oldState.ships.size(); k++) {
//				temp.add(oldState.ships.get(k));
//			}
//			
//			
//			
//			ArrayList<String> actions = new ArrayList<String>();
//			
//			for (int j=0; j < oldState.actions.size() ; j++) {
//				actions.add(oldState.actions.get(j));
//			}
//			
//			actions.add("right");
//			
//			for (int i=0; i < oldState.ships.size(); i++) {
//				temp.add(shipClone((Ship)oldState.ships.get(i)));
//				
//			}
//			
//			newState = new AgentState(oldState.agentX, oldState.agentY+1, oldState.passengersOnBoard, oldState.boxesRetrieved, temp, "right", actions);
//			
//			for (int k=0 ; k < newState.ships.size() ; k++) {
//				newState.ships.get(k).damage();
//			}
//			
//		}
//		
//		System.out.println("parent p after: "+oldState.ships.get(0).p);
//		return newState;
//	}
//	
//	public static AgentState moveLeft(AgentState oldState) throws CloneNotSupportedException {
//		AgentState newState = null;
//		if (oldState.agentY != 0) {
//			System.out.println("left");
//			
//			System.out.println("parent p before: "+oldState.ships.get(0).p);
//			
//			ArrayList<String> actions = new ArrayList<String>();
//			
//			for (int j=0; j < oldState.actions.size() ; j++) {
//				actions.add(oldState.actions.get(j));
//			}
//			
//			actions.add("left");
//			
//			newState = new AgentState(oldState.agentX, oldState.agentY-1, oldState.passengersOnBoard, oldState.boxesRetrieved, oldState.ships, "left",actions);
//			
//			for (int k=0 ; k < newState.ships.size() ; k++) {
//				newState.ships.get(k).damage();
//			}
//			
//		}
//		
//		System.out.println("parent p after: "+oldState.ships.get(0).p);
//		return newState;
//	}
//	
//	
//	public static AgentState pickup(AgentState oldState, Ship ship) throws CloneNotSupportedException{
//		AgentState newState = null;
//		
//		boolean canPickup = false;
//		
//		ArrayList<String> actions = new ArrayList<String>();
//		
//		for (int j=0; j < oldState.actions.size() ; j++) {
//			actions.add(oldState.actions.get(j));
//		}
//		
//		actions.add("pickup");
//		
//		newState = new AgentState(oldState.agentX, oldState.agentY, oldState.passengersOnBoard, oldState.boxesRetrieved, oldState.ships, "pickup",actions);
//
//		while (oldState.passengersOnBoard <= agent.getC()) {
//			if(ship.getP() > 0) {
//				canPickup = true;
//				System.out.println("pickup");
//				
//				System.out.println("parent p before: "+oldState.ships.get(0).p);
//				
//				newState.passengersOnBoard++;
//				
//				for (int k=0 ; k < newState.ships.size() ; k++) {
//					if (newState.ships.get(k).getX() == oldState.agentX && newState.ships.get(k).getY() == oldState.agentY) {
//						newState.ships.get(k).setP(ship.getP()-1);
//					}
//				}
//				
//			}		
//		}
//		
//		if (canPickup) {
//			for (int k=0 ; k < newState.ships.size() ; k++) {
//				newState.ships.get(k).damage();
//			}
//		}
//		
//		System.out.println("parent p before: "+oldState.ships.get(0).p);
//		return newState;
//		
//	}
//	
//	public static AgentState retrieve(AgentState oldState, Ship ship) throws CloneNotSupportedException{
//		AgentState newState = null;
//		
//		ArrayList<String> actions = new ArrayList<String>();
//		
//		for (int j=0; j < oldState.actions.size() ; j++) {
//			actions.add(oldState.actions.get(j));
//		}
//		
//		actions.add("retrieve");
//		
//		newState = new AgentState(oldState.agentX, oldState.agentY, oldState.passengersOnBoard, oldState.boxesRetrieved, oldState.ships, "retrieve",actions);
//		
//		if(ship.getDamage() < 100) {
//			System.out.println("retrieve");
//			newState.boxesRetrieved++;
//			
//			for (int k=0 ; k < newState.ships.size() ; k++) {
//				if (newState.ships.get(k).getX() == oldState.agentX && newState.ships.get(k).getY() == oldState.agentY) {
//					newState.ships.get(k).boxState = BoxState.Destroyed;
//				}
//			}
//			
//			for (int k=0 ; k < newState.ships.size() ; k++) {
//				newState.ships.get(k).damage();
//			}
//			
//		}
//		
//		
//		return newState;
//	}
//	
//	public static AgentState drop(AgentState oldState) throws CloneNotSupportedException{
//		AgentState newState = null;
//
//		if(grid[oldState.agentX][oldState.agentY].station && oldState.passengersOnBoard > 0) {
//			System.out.println("drop");
//			
//			ArrayList<String> actions = new ArrayList<String>();
//			
//			for (int j=0; j < oldState.actions.size() ; j++) {
//				actions.add(oldState.actions.get(j));
//			}
//			
//			actions.add("drop");
//			
//			
//			newState = new AgentState(oldState.agentX, oldState.agentY, 0, oldState.boxesRetrieved, oldState.ships, "drop",actions);
//			
//			for (int k=0 ; k < newState.ships.size() ; k++) {
//				newState.ships.get(k).damage();
//			}
//			
//		}
//		
//		return newState;
//	}
//	
//	public static String bfs() throws CloneNotSupportedException {
//		
//		Queue<AgentState> bfsQueue = new LinkedList<>();
//		String result = "";
//		
//		ArrayList<String> initialActions = new ArrayList<String>();
//		
//		AgentState agentState = new AgentState(agent.getX(),agent.getY(),0,0,ships,"",initialActions);
//		bfsQueue.add(agentState);
//		
//		while (bfsQueue.size() > 0)  {
//			AgentState ag = bfsQueue.remove();
//			
//			switch(ag.operator) {
//			
//			case "up":       result += "up,"       ; break;
//			case "down":     result += "down,"     ; break;
//			case "left":     result += "left,"     ; break;
//			case "right":    result += "right,"    ; break;
//			case "pickup":   result += "pickup,"   ; break;
//			case "drop":     result += "drop,"     ; break;
//			case "retrieve": result += "retrieve," ; break;
//			default: break;
//			
//			}
//			
//			if(IsGoal(ag)) {
//				break;
//			}
//			
//			AgentState up = moveUp(ag);
//			if (up != null) {
//				bfsQueue.add(up);
////				System.out.println("can move up");
//			}
//			
//			AgentState down = moveDown(ag);
//			if (down != null) {
//				bfsQueue.add(down);
////				System.out.println("can move down");
//			}
//			
//			AgentState right = moveRight(ag);
//			if (right != null) {
//				bfsQueue.add(right);
////				System.out.println("can move right");
//			}
//			
//			AgentState left = moveLeft(ag);
//			if (left != null) {
//				bfsQueue.add(left);
////				System.out.println("can move left");
//			}
//			
//			Ship sh = null;
//			for (int k=0 ; k < ag.ships.size() ; k++) {
//				if (ag.ships.get(k).getX() == agent.getX() && ag.ships.get(k).getY() == agent.getY()) {
//					sh = ag.ships.get(k);
//				}
//			}
//			
//			if (sh != null) {
//				AgentState pickup = pickup(ag,sh);
//				if (pickup != null) {
//					bfsQueue.add(pickup);
//					System.out.println("can pickup");
//				}
//				
//				AgentState retrieve = retrieve(ag,sh);
//				if (retrieve != null) {
//					bfsQueue.add(retrieve);
//					System.out.println("can retrieve");
//				}
//			}
//			
//			
//			AgentState drop = drop(ag);
//			if (drop != null) {
//				bfsQueue.add(drop);
//				System.out.println("can drop");
//			}
//			
//		}
//		
//		return result;
//	}
//	
//	public static boolean IsGoal(AgentState s) {
////		boolean hasPassengers = false;
////		boolean hasBoxes = false;
//
//		for(int i = 0 ; i < s.ships.size() ; i++) {
//			if(s.ships.get(i).p > 0) {
////				hasPassengers = true;
//				return false;
//			}
//			
////			if(!s.ships.get(i).boxState.equals(BoxState.Destroyed)) {
//////				hasBoxes = true;
////				return false;
////			}
//				
//		}
//		
//		return true;
//	}
//	
//	
//	public static String Solve(String grid, String strategy, boolean visualize) {
//		String res = "";
//		
//		switch(strategy) {
//		case "BF" : try {
//				return bfs();
//			} catch (CloneNotSupportedException e) {
//				e.printStackTrace();
//			}
//		case "DF" : break;
//		case "ID" : break;
//		case "GR1" : break;
//		case "GR2" : break;
//		case "AS1" : break;
//		case "AS2" : break;	
//		}
//		
//		return res;
//	}
//
//	public void totalDeaths(ArrayList<Ship> ships) {
//		for (int i = 0 ; i > ships.size() ; i++) {
//			deaths += ships.get(i).deceased;	
//		}
//	}
//
////	@Override
////	protected Object clone() throws CloneNotSupportedException {
////        AgentState s = (AgentState)super.clone();
////        return s;
////    }
//	
//	
//	
//	public static Ship shipClone(Ship sh) {
//		Ship newShip = new Ship();
//		newShip.p = sh.p;
//		newShip.boxState = sh.boxState;
//		newShip.wreck = sh.wreck;
//		newShip.x = sh.x;
//		newShip.y = sh.y;
//		newShip.p = sh.p;
//		newShip.deceased = sh.deceased;
//		newShip.damage = sh.damage;
//		
//		return newShip;
//	}
//	
//	
//	@SuppressWarnings("unchecked")
//	public static void main(String[] args) {
////		System.out.println(GenGrid());
//		
////		m=2;
////		n=2;
////		
////		grid = new Cell[2][2];
////		
////		for (int i = 0; i < 2; i++) {
////			for (int j = 0; j < 2; j++) {
////				grid[i][j] = new Cell(2,2);
////				grid[i][j].setX(i);
////				grid[i][j].setY(j);
////			}
////
////		}
////		
////		agent = new Agent();
////		System.out.println("agent's capacity: "+agent.getC());
////		
////		agent.setX(0);
////		agent.setY(0);
////		
////		Ship sh = new Ship();
////		sh.setX(0);
////		sh.setY(1);
////		ships.add(sh);
////		grid[0][1].setEmpty(false);
////		grid[0][1].setShip(true);
////		
////		System.out.println("ship's p:"+sh.getP());
////
////		
////		grid[1][0].setEmpty(false);
////		grid[1][0].setStation(true);
////		grid[1][0].setX(1);
////		grid[1][0].setY(0);
////		
////		try {
////			System.out.println(bfs());
////		} catch (CloneNotSupportedException e) {
////			// TODO Auto-generated catch block
////			e.printStackTrace();
////		}
//		
//		
//		ArrayList<Ship> amira = new ArrayList<Ship>();
//		amira.add(new Ship());
//		amira.add(new Ship());
//		amira.add(new Ship());
//		
//		
//		ArrayList<Ship> oss = new ArrayList<Ship>();
//		
//		//oss =  amira.get(0).setP(amira.get(0).getP()-1);
//		
//		for (int k =0; k< amira.size(); k++) {
//			//oss.add(amira.get(k));
//			Ship s = new Ship();
//			s.p = amira.get(k).p;
//			oss.add(s);
//		}
//		
//		amira.get(0).boxState = BoxState.Destroyed;
//		
//		for (int i = 0; i < oss.size() ; i++) {
//			System.out.println(oss.get(i).boxState);
//		}
//		
//	}
//}
