package code;

public enum BoxState {
	Available, Destroyed, Collected;
}
